#!/usr/bin/python3
class Siva(object):
	a=2
	c=1
	def __init__(self,a,c):
		self.a=a
		self.c=c
	def s(self,d,s):
		print(self.a+self.c)
		self.d=d
		self.s=s
		return d+s
	def cdd(self):
		return self.d 
		
obj=Siva(1,2)
print(obj.s(5,6))
print(obj.cdd())
