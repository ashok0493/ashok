#!/usr/bin/python3
class Everest:
	"this class is used for get a employee details"
	def __init__(self,a,b):
		self.a=a
		self.b=b
	def Add(self,e,f):
		print(self.a)
		return e+f
if __name__=="__main__":		
	obj=Everest();
	obj.Add(1,2)
#print(obj.a)
