#!/usr/bin/python3
class Mywish:
	'''this is my second class'''
	a=10
	def fun(self):
		print(self)
		print('hello')
	fun(1)		
print(Mywish.__doc__)		
print(Mywish.a)		
print(Mywish.fun(1))#no calling function at class	
#print(a)		
obj=Mywish()	
print(obj.fun())
print(Mywish.fun)
print(obj.fun)

bj=Mywish()
print(bj)
print(obj)


