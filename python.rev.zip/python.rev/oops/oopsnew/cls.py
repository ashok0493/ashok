#!/usr/bin/python3
class siva:
	def add(self,a,b):
		self.a=a
		self.b=b
		return a+b
	def sub(self,c,d):
		self.c=c
		self.d=d
		return c-d
#obj=siva()
#print(obj.add(1,2))
#print(obj.sub(4,3))
class siva1(siva):
	def csv(self,e,f):
		self.e=e
		self.f=f
		return e*f
obj1=siva1()
print(obj1.add(6,7))
print(obj1.a)
