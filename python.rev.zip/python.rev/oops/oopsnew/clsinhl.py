#!/usr/bin/python3
class A:
	def __init__(self,name):
		self.name=name
	def sss(self):
		return self.salary
class B(A):
	def __init__(self,age,name):
		A.__init__(self,name)
		self.age=age
class C(B):
	def __init__(self,age,name,salary):
		B.__init__(self,age,name)
		self.salary=salary
	def fun(self):
		return self.salary,self.age,self.name

obj=C('a','b',79798)
print(obj.fun())
print(obj.sss())
