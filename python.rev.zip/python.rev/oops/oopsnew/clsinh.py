#!/usr/bin/python3
class Base1():
	def __init__(self,str1):
		self.str1="geek1"
		print("Base1")
class Base2():
	def __init__(self):
		self.str2="geek2"
		print("Base2")
class Derived(Base1,Base2):
	def __init__(self):
		Base1.__init__(self,str1)
		Base2.__init__(self)
		print ("Derived")
	def printStrs(self):
		print(self.str1,self.str2)
obj2=Base1(1)
obj1=Derived()
obj1.printStrs()
