#!/usr/bin/python3
class A():
	def __init__(self):
		self.a='a'
		print(self.a)
class B(A):
	def __init__(self):
		self.b='b'
		print (self.b)
class C(A):
	def __init__(self):
		self.c='c'
		print (self.c)
class D(B,C):
	def __init__(self):
		self.d='d'
		print (self.d)
		super(D,self).__init__()
obj=D()
