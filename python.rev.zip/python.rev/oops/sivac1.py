#!/usr/bin/python3
class base():
	a=10
	b=20
	def __init__(self,a=1,b=3):
		pass
#		self.a=a
#		self.b=b
	def add (self):
		print(self.a,self.b)
obj=base()
#del obj.a
obj.add()
