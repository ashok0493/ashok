#!/usr/bin/python3
from task7 import East
obj=East()
obj.add("s.csv")
obj.emp_id("sr01")
