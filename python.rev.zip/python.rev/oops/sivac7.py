#!/usr/bin/python3

class Siva(object):
	def __init__(self,a,b):
		self.x=a
		self.y=a
		print(self.x,self.y)
Siva(1,2)





'''class Myclass(object):
	def add(self,a,b):
		self.a=a
		print(self.a)
		print(self.n)
		print("hello")
		return
#Myclass.add()		
obj=Myclass()
obj.n=12
obj.add(33)'''
