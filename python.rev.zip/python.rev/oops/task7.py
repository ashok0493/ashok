#!/usr/bin/python3
import sys
class East:
	"csv file reader in using classes"
	def __init__(self):#constructor python and create attributes
		self.d={}
	def emp(self,a):
		a=open(a,"r")
		b=a.readline()
		c=b.strip()
		d=c.split(',')
		e=a.readlines()
		for i in e:
			f=i.strip()
			g=f.split(',')
			self.d[g[0]]={}
			self.d[g[0]][d[1]]=g[1]
			self.d[g[0]][d[2]]=g[2]#for loop end and build in dictionary
		return self.d	#emp function end		
	def emp_id(self,b):
		if b in self.d:
			print("emp_id  : ",b)
			for k,v in self.d[b].items():#get a employee details
				print(k ," :",v)
		else:
			print("---------enter emp_id is not found--------")
			print("********required emp_id numbers are sr01 to sr03*********")
		return #emp_id function end
if __name__=="__main__":
	obj=East()#create a object
	obj.emp(sys.argv[1])#csv file taken in command line		
	obj.emp_id(sys.argv[2])#emp_id taken in command line

