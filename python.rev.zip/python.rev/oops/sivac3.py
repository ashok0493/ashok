#!/usr/bin/python3
class Myclass:
	a=9
	def __init__(self,a=0):
		self.a=a
	def add(self,s):
		print("hello")
		self.s=s
		print(self.s)
o=Myclass()
#del o.a
print(o.add(22))
print(o.a)
print(delattr(o,'a'))
print(setattr(o,'a',22222))
print(getattr(o,'a'))
print(hasattr(o,'a'))
