#!/usr/bin/python3
class ash:
	def add(self,a,b):
		b=a+b;
		return b
class kmr(ash):
	def add(self,a,b,c):
		x=a*b;
		return x;
c=kmr();
m=ash();
d=m.add(10,30)
print(d)
