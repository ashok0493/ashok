#!/usr/bin/python3
d={'a':[1,2,3,{'c':6},4,5]}
for k,v in d.items():
	for s in v:
		if type(s) == dict:
			print(type(s))
			for q,w in s.items():
				print(q,w)

