#!/usr/bin/python3
class Myclass:
	"this is 3rd class "
	def __init__(self,*a,s=0):
		self.a=a
		self.s=s
	def fun(self,a):
		print(self.n)
		for i in self.a:
			self.s+=i
		return self.s	
a=Myclass(333,22,22,11)		
a.n=11
print(a.fun(33))
