#!/usr/bin/python3
class A:
	def width(self):
		print("a,width called")
class B(A):
	def size(self):
		print("b,size called")
k=B()
k.size()
k.width()

