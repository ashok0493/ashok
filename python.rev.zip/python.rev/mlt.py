'''import time
def cal_square(num):
	print("cal squre num")
	for n in num:
		time.sleep(0.2)
		print("square:",n*n)
def cal_cube(num):
	print("cal cub num")
	for n in num:
		time.sleep(0.2)
		print("cube:",n*n*n)
l=[1,2,3,4]
t=time.time()
print(t)
cal_square(l)
cal_cube(l)
t1=time.time()
print(t1,"\n\n")
print(t1-t)


#print("done in :",time.time()-t)
#print("hah..i am done with all my work now")'''

import time
import threading
def cal_square(num):
	print("cal squre num")
	for n in num:
		time.sleep(0.2)
		print("square:",n*n)
def cal_cube(num):
	print("cal cub num")
	for n in num:
		time.sleep(0.2)
		print("cube:",n*n*n)
l=[1,2,3,4]
t=time.time()
print(t)
t1=threading.Thread(target=cal_square,args=(l,))
t2=threading.Thread(target=cal_cube,args=(l,))
t1.start()
t2.start()
t1.join()
t2.join() 
t3=time.time()
print(t3)
print("\n\n")
print("done in :",t3-t)
#print("hah..i am done with all my work now")
