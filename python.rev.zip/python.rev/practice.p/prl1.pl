#!/usr/bin/perl
@a=(1,2,3);
unshift(@a,0);
print"@a";

