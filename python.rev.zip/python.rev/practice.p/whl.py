#!/usr/bin/python3
o=0
ap=0
while o!=-1:
	print("enter number of o:")
	o=float(input())
	print("enter number of ap:")
	ap=float(input())
	if o==0:
		break
print(o+ap)
#	print(ap)
