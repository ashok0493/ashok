#!/usr/bin/python3
l=[1,2,3,4,5,6,7,8,9]
for k in l:
	while k<9:
		print(k)
		
