#!/usr/bin/python3
l=[1,2,3,4,5,6,7,8,9,10]
s=[]
for v in l:
	if v%2:
		s.append(v)
	if len(s)==3:
		break
print(s)

#v%2 means ==1 to print odd values to break the condition

'''
for v in l:
	if v%2:
		print(v)
		i=i+1
	if i==3:
		break
'''
