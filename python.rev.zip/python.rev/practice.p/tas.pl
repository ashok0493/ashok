#!/usr/bin/python3
l=[1,2,3,4,5,6,7,8,9,11,13,14]
'''
i=0
for v in l:
	while v<6:
		print(v)
		v=v+1
	print(i)
'''
i=1
for v in l:
	if i%2==0:
		print(l[i-2])
	i=i+1
