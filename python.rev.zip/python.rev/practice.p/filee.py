#!/usr/bin/python3
'''
f=open("dta.txt","r")
d=f.readlines()
j={}
'''
def lst(*l):
	global j
	j={}
	for v in l:
		g=v.strip()
		h=g.split()
		#print(h)
		for k in h:
			if k in j:
				j[k]+=1
			else:
				j[k]=1
	return j


if __name__=="__main__":
	e=open("dta.txt","r")
	r=e.readlines()
	u=lst(*r)
	print(j)
