#!/usr/bin/perl
print"enter number:";
$input=<>;
chomp $input;
$a=622;
%h=('ashok'=>500,'srinu'=>500,'govind'=>550);
print $h{$input}-$a;

