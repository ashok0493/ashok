#!/usr/bin/perl
=head
sub hsh{
	my (%h)=@_;
	#print %h;
	foreach $k (keys (%h)){
		my $v=$h{$k};
		print"$k:$v\n";
	}
}
%h=('name'=>'tom','age'=>20);
hsh(%h);
=cut
sub ar{
	my $n=@_;
	print"@_[0]";
}
@r=(1,2,3,4,5);
ar(@r);
