#!/usr/bin/perl
$a="abcdefgh";
$b=chomp($a);
print"$b\n";
