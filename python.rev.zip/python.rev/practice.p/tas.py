#!/usr/bin/python3
def lst(*s):
	d=0
	for v in s:
		d=d+v
	return d
l=[1,2,3,4,5]
print(lst(*l))
