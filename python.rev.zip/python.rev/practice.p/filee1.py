#!/usr/bin/python3
from filee import *
s=open("filex.txt","r")
d=s.readlines()
v=lst(*d)
print(v)
