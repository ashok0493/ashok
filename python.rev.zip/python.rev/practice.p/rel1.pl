#!/usr/bin/perl
$p=[1,2,3,{'a'=>[4,5,6,{'b'=>[7,8,9],'c'=>10},11,12]},13,14];
foreach $b (@{$p}){
	if (ref($b) ne "HASH"){
		print"$b\n";
	}
	else{
		foreach $h (@{$p->[3]->{'a'}}){
			if (ref($h) ne "HASH"){
				print"$h\n";
			}
			else{
				foreach $k (keys(%{$p->[3]->{'a'}->[3]})){
					if ($k ne 'c'){
						print"$k=@{$p->[3]->{'a'}->[3]->{$k}}\n";
					}
					else{
						print"$k=$p->[3]->{'a'}->[3]->{$k}\n";

						}
				 }
			 }
		}
	}
}
