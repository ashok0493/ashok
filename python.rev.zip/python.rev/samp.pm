#!/usr/bin/perl
package samp;
sub fun1{
	$mul=1;
	foreach $k (@_){
		$mul*=$k;
	}
	return $mul;
}
1;
	
