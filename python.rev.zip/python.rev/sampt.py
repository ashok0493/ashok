#!/usr/bin/python3
l=[[1,2,3],[4,5,6],[7,8,9]]
j=0;
for v in l:
	for k in v:
		if j==0:
			print(k)
			j=j+1
			break
		elif j==2:
			print(k)
			j=j+1
			break
		elif j==5:
			print(k)
		j=j+1
