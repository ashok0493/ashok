#!/usr/bin/python3
fob=open("text1.txt","r")
m=fob.read()
fobj=open("new.txt","w")
k=fobj.write(m)
