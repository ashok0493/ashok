#!/usr/bin/python3
'''s=open("file2.txt","r+")
s.seek(10)
s.write("marthahali")
s.seek(0)
print(s.readline())'''
s=open("file2.py","r+")
s.seek(48)
#print(s.readline())
#print(s.read())
s.write("DDDDDDDDDDDDDDDDDD")
print(s.read())
#l=s.readlines()
#print(l)

