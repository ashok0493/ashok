#!/usr/bin/python3
import re
obj=open("file2.txt","r")
#print(obj.readlines())
l=obj.readlines()
#print(l.split( ))
for v in l:
	#f=re.sub(r'(.*?)(of\s)(\w+)',r'\g<1> \g<2> tollywood',v)
	f=re.sub(r'(.*?)(of\s)(\w+)',r'\1\2 tollywood',v)
	fobj = re.search(r'(.*?)(ollywood)',f)
	if  fobj:
		print(fobj.group(2))

