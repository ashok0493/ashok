#!/usr/bin/python3
mobj=open("text.txt","r+")
#print(mobj.readline())
position=mobj.tell()
print(position)
cursor=mobj.seek(10)
mobj.write("zamshedpr")
print(mobj.readlines())


