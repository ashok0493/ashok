#!/usr/bin/python3
k=open("text.txt","r")
#print(k.read())
print(k.readline())
print(k.readlines())
