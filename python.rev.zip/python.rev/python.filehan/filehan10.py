#!/usr/bin/perl
i=input("enter a number");
fobj=open("new.txt","r");
k=fobj.read()
print(k)
