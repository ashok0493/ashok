#!/usr/bin/python3
#obj=open("file2.txt","w")
#obj.write("opens a file for reading only the file pointer is placed at the begining of the default mode");
obj=open("file2.txt","r")
m=obj.read()
#print(m)
k=m.split()
b=[]	
for v in k:
	l=len(v)
	b.append(l)
for c in k:
	s=len(c)
	if max(b)==len(c):
		print(s,c)	
