#!/usr/bin/python3
str=open("filet1.txt","w")
l=str.write("python3 tutorial")
print(l)
