#!/usr/bin/python3
import os
#os.rename("filehan4.py","filehan2.py")
#os.mkdir("emptyfol")
#os.chdir("/home/ashok-pc/Desktop/emptyfol")
#os.mkdir("dupl")
#print(os.get())
os.rmdir("/home/ashok-pc/Desktop/folder")

