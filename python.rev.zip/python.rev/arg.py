#!/usr/bin/python3
import sys;
#print("enter argument",len(sys.argv))
#print(''.join(sys.argv),sys.argv[0])
#print(''.join(sys.argv))
print(sys.argv[0]),"\n";
print(sys.argv[1]),"\n";
print(sys.argv[2]),"\n";
for x in sys.argv:
	print("arguments",x)
