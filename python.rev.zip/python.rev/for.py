#!/usr/bin/python3
list1=[1,2,3,4,5,1,6,1,7]
for i in list1:
	if i==1:
		#print(i)
		#break
		continue
	print(i)
	#break
	#print(i)
