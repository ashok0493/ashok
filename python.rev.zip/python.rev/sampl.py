#!/usr/bin/python3
import sys;
ip=int(sys.argv[1])
x=1
for v in range(1,ip+1):
	x=x*v
print(x)
