#!/usr/bin/python3
tr="jhgkjh kjhkh kjhkl kjhik kjhkl khlkkjhkh kjhlkhkjnhl khiklih knkn"
print(tr.count(' '))#count in space
