#!/usr/bin/python3
l=[900,33,-1,44,66,88,6,2,4,5,799,3,4,7,8,9,9]
a=l[0]
for i in l:
	if i>a:#maximu word in list, minimum is(<)
		a=i
print(a)



l.sort()
print(l)
print(l[len(l)-2])
