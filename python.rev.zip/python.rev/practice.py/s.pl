#!/usr/bin/perl
%h=('s'=>3,'a'=>2);
@a=(1,2,3,4,4,5);
$d='siva';
add(\%h,\@a,\$d);
sub add{
	$k=${$_[2]};
	@s=@{$_[1]};
	%c=%{$_[0]};
	print($k);
	print(%c);
	print(@s);
	}





	
