#!/usr/bin/python3
l=[1,2,3,4,5,6,71,1,1,3,1,4,55,1,11,1,3,4]
d={}
for i in l:
	if i in d:
		d[i]+=1
	else:
		d[i]=1
a=max(d.values())
for k,v in d.items():
	if a==v:
		print("highest value:",k,"count:",v)
