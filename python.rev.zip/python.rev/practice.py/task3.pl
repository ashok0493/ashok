#!/usr/bin/perl
$open_flag=0;
open ($data,"<f1");
@lines=<$data>;
foreach $a (@lines){
	if($a=~/\w+\s+\{/){
		@sss=split('\s+',$&);
		$open_flag=1;
		}
	elsif ($a=~/\s+\}/){
		print($sss[0],":",$sum,"\n");
		$sum=0;
		$open_flag=0;		
		}
	elsif($open_flag){
		@x=split('\s+',$a);
		foreach $z (@x){
			$sum+=$z;
			}
	}
}
