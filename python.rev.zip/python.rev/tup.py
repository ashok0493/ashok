#!/usr/bin/python3
tup=('ashok','siva','srinu')
tup2=(1,2,3,4,5,6)
tup1=tup+tup2
print(tup1)
del tup2
print(tup)
stn=len(tup1)
print(stn)
tup3=("hi")*4
tup4=(5,6,7,8,9)
print(tup3)
#tnr=cmp(tup4,tup)
#print(tnr)
print(max(tup4))
list1=list(tup4)
print(list1)
#tup6=tup(list1)
#print(tup6)
for v in tup4:
	print(v,end=' ')
print(6 in (tup4))

