#!/usr/bin/python3
"""fob=open("file1.txt","w");
fob.write("Born to a Gujarati family in Vadnagar, Modi helped his father sell tea as a child, and later ran his own stall. He was introduced to the right-wing Hindu nationalist organisation Rashtriya Swayamsevak Sangh at the age of eight, beginning a long association with the organisation. He left home after graduating from school, partly because of an arranged marriage which he rejected. Modi traveled around India for two years, and visited a number of religious centres. He returned to Gujarat and moved to Ahmedabad in 1969 or 1970. In 1971 he became a full-time worker for the RSS. During the state of emergency imposed across the country in 1975, Modi was forced to go into hiding. The RSS assigned him to the BJP in 1985, and he held several positions within the party hierarchy until 2001, rising to the rank of general secretary.")
"""
fobj=open("file1.txt","r");
str=fobj.readline(10)
print(str)
position=fobj.tell();
print(position)
position=fobj.seek(10,2)
print(position)
print(str)
