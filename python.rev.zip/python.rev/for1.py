#!/usr/bin/python3
#str="pichafruit"
fruit=['banana','apple','mango','strawberry','grape']
"""for index in range(len(fruit)):
	print(fruit[index])
	
for v in range(10):
	if v<=3:
		#break
		#break
		continue
	print(v)

for v in str:
	print(v)
print(v)"""

"""#numbers=[11,33,47,55,39,75,37,21,23]

for n in numbers:
	if n%2==0:
		#break
		print("the list contain even number")
		break
else:
	print("the list doesnt contain evn number")"""
var=10
while var>0:
	print(var)
	var=var-1
	if var==5:
		break
	var=var-1 
