#!/usr/bin/python3
import re
line="hi this is ashok and my contact no 9030196569 and 8328651529 maid id is ashok@gmail.com and ashok2@gmail.com"
#mobj=re.search(r'smater',line)
#mobj=re.match(r'(\s*(\w+)\s(.*)\s(\w+))',line)
mobj=re.findall(r'\d+,\w+@\w+\.\w+',line)
#print(mobj.group())
if mobj:
	print(mobj)
else:
	print("nothing found")

