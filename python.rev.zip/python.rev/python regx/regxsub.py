#!/usr/bin/python3
import re
str="hello this is srmicro near munneykolala"
#mobj=re.sub(r'(.*)\s(\w+)\s(\w+)',r'\1 \2 amruthabakery',str)
#print(mobj)
mobj=re.sub(r'(.*)\s(\w+)\s(\w+)',"\g<1> \g<2> amruthabakry",str)
print(mobj)
