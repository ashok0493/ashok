#!/usr/bin/python3
import re
str="my name is ashok"
mobj=re.sub(r'ashok','pawan',str)
print(mobj)
