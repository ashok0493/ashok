#!/usr/bin/python3
a=0
b=1
print(a,b)
c=a+b
while c<20:
	print(c)
	a=b
	b=c
	c=a+b
