#!/usr/bin/python3
'''import os
os.system('ifconfig')
os.system('ifconfig wlan0|grep "inet\ addr"|cut -d: -f2|cut -d" " -f1')'''


import subprocess
k=subprocess.checkout('ifconfig')


import os
b=os.popen('ifconfig')
