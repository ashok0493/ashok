#!/usr/bin/python3
"""n=int(input("enter number:"))
i=0
l=[]
while i<n:
	s=input("enter string:")
	a=s.upper()
	l.append(a)
	i=i+1
print(l)
n=int(input("enter number:"))"""
#function method
def name(n):
	i=0
	l=[]
	while i<n:
		s=input("enter string:")
		a=s.upper()
		l.append(a)
		i=i+1
	return l
n=int(input("enter number:"))
print(name(n))
