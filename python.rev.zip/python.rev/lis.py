#!/usr/bin/python3
list1=[1,2,3,5,6]
list2=[7,8,9,10,12]
tup=(2,3,4,5,6,78)
#print(list1[1])
#str=cmp(list1,list2)i
#list3=list(tup)
#print(len(list1))
#print(list3)
tup=tuple(list1)
print(tup)

