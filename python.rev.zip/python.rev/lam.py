#!/usr/bin/python3
from functools import reduce
#lambda
sum=lambda x,y:x+y
print(sum(5,8))
#map
list2=[1,2,3,4,5,6]
s=list(map(lambda x:x+2,list2))
print(s)
#filter
k=list(filter(lambda x:x%2,list2))
print(k)
#reduce
r=reduce(lambda x,y:x+y,list2)
print(r)
