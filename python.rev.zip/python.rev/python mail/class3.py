class SchoolMember:
    '''Represents any school member.'''
    def __init__(self, name, age, salary):
        self.name = name
        self.age = age
        self.salary = salary
        print('(Initialized SchoolMember: {})'.format(self.name))

    def tell(self):
        '''Tell my details.'''
        print('School Member: Name:"{}" Age:"{}"'.format(self.name, self.age), end="\n")


class Teacher(SchoolMember):
    '''Represents a teacher.'''

    def tell(self):
        print('Teacher: Name:"{}" Age:"{}"'.format(self.name, self.age), end="\n")

class Student(SchoolMember):
    '''Represents a student.'''

    def tell(self):
        print('Student: Name:"{}" Age:"{}"'.format(self.name, self.age), end="\n")


if __name__ == "__main__":
    t = Teacher('Mrs. Shrividya', 40, 30000)
    s = Student('Swaroop', 25, 75)

    # prints a blank line
    print()

    members = [t, s]
    for member in members:
      # Works for both Teachers and Students
      member.tell();


