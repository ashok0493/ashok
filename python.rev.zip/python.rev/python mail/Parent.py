#!/usr/bin/python3
class Parent(object):
	def add(self,x,y):
		sum = x + y;
		return sum;

class Child(Parent):
	pass;
	def add(self,x,y,z):
		sum = x + y + z;
		return sum;
	

c = Child();

sum = c.add(10,20,30);
print(sum);
