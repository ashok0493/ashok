import sys
for a in range(int(sys.argv[1])):
	if a>1:
		for b in range(2,a):
			if a%b==0:
				break
		else:
			print(a)
