#!/usr/bin/python3
import sys;
sys.path.append("/home/ashok-pc/Desktop")
import mod
m=[2,3,4,5,6]
print(mod.l(*m))
'''
from mod import k
s=[1,2,3,4,5]
print(k(*s))'''
