#t!/usr/bin/python3

s={}
def dic(**kwar):
	for k,v in kwar.items():
		s[k]=v
	return s

def di(**k):
	for k,v in k.items():
		print(k,v)
	return "success"

def lst(*l):
	sum=0
	for v in l:
		sum+=v
	return sum

if __name__=="__main__":
	d1={'a':3,'b':5,'c':8}
	e=dic(**d1)
	print(e)
	d2={'m':45,'n':51}
	f=di(g=21,**d2)
	print(f)	
	i=[1,2,3,5,9]
	r=lst(*i)
	print(r)
