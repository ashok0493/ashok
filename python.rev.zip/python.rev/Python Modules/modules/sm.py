#!/usr/bin/python3
#import sys
#print(sys.path)
#sys.path.append("/home/ashok-pc/Desktop")
from deff import dic,di,lst
d={'c':53,'d':56}
print(dic(**d))
f={'e':15,'f':25}
print(di(**f))
l=[1,3,5,6,7]
print(lst(*l))


'''
import deff
d={'a':15,'b':20}
print(deff.dic(**d))'''
