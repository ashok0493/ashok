#!/usr/bin/python3
def l(*l):
	s=0
	for v in l:
		s=s+v
	return s

def k(*d):
	v=1
	for m in d:
		v=v*m
	return v


if __name__=="__main__":
	s=[1,2,3,4,5]
	j=l(*s)
	print(j)
	n=[1,5,10,15,20]
	m=k(*n)
	print(m)
