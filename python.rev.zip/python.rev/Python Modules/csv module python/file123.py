#!/usr/bin/python3
import sys;
sys.path.append("/home/ashok-pc/");
import buildic;
k=buildic.csv("filex.csv")
buildic.data_id(sys.argv[1])
#print(k)
