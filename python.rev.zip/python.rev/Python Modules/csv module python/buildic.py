#!/usr/bin/python3
import sys;
def csv(n):
	m=open("filex.csv","r")
	k=m.readline()
	n=k.strip()
	j=n.split(',')
	p=m.readlines()
	global d
	d={}
	for v in p:
		s=v.strip()
		t=s.split(',')
		d[t[0]]={}
		d[t[0]][j[1]]=t[1]
		d[t[0]][j[2]]=t[2]
		d[t[0]][j[3]]=t[3]
	return d
def data_id(n):
	if n in d:
		for k,v in d[n].items():
			print(k,v) 
	else:
		print("enter id not in range")
		print("required id's is id1,id2,id3")
	return 	
