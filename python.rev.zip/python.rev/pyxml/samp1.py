#!/usr/bin/python3
import xml.etree.ElementTree as ET
tree=ET.parse("samp.xml")
root=tree.getroot()
#print(root)
#print(root.tag)
#print(root.attrib)
#for v in root:
	#print(v)
#	print(v.tag,v.attrib)
#print(root[0][1].text)
#for neighbor in root.findall('neighbor'):
#	print(neighbor.attrib)
for v in root:
	print(v.get('name'))
	print(v.find('rank').text)

