#!/usr/bin/python3
import xml.etree.ElementTree as ET
from pprint import pprint
file=ET.parse("basic.xml")
root=file.getroot();
obj=open("file.csv","w")
import pymysql
db=pymysql.connect("localhost","root","ashok","csv")
cur=db.cursor()
cur.execute("drop table if exists xml")
cur.execute("create table xml(ID varchar(11) not null,Name varchar(255) not null,skills varchar(255) not null,salary int(11) not null)")
db.commit()
emp_data={}
for v in root.findall("emp"):
	emp_id=v.get('id')
	name=v.find('name').text
	skills=v.find('skills').text
	salary=v.find('salary').text
	cur.execute("insert into xml values('{}','{}','{}',{})".format(emp_id,name,skills,salary))
	db.commit()	
	emp_data[emp_id]={}
	emp_data[emp_id]["name"]=name
	emp_data[emp_id]["skills"]=skills
	emp_data[emp_id]["salary"]=salary
#print(emp_data)
l=[]
cur.execute("desc xml")
for v in cur.fetchall():
	l.append(v[0])
header=','.join(l)
obj.write(header)
obj.write("\n")
cur.execute("select * from xml")
for h in cur.fetchall():
	s=[]
	for i in h:
		s.append(str(i))
	line=','.join(s)
	print(line)
	obj.write(line)
	obj.write("\n")
