#!/usr/bin/python3
import pymysql
db=pymysql.connect("localhost","root","ashok","csv");
cur=db.cursor()
cur.execute("select * from xml")
column=[k[0] for k in cur.description]
allrows=cur.fetchall();
#print(allrows)
#for v in cur.fetchall():
xmlfile=open("file.xml","w")
xmlfile.write('<data>')
xmlfile.write("\n")
for rows in allrows:
	xmlfile.write('<row>')
	xmlfile.write("\n")
	columnnumber=0
	for c in column:
		data=rows[columnnumber]
		if data == None:
			data=''
		xmlfile.write('<%s>%s</%s>' % (c,data,c))
		xmlfile.write("\n")
		columnnumber+=1
	xmlfile.write('</row>')
	xmlfile.write("\n")
xmlfile.write('</data>')
xmlfile.close()
