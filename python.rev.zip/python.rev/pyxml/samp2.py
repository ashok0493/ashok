#!/usr/bin/python3
import xml.etree.ElementTree as ET
tree=ET.parse("samp.xml")
root=tree.getroot()
'''
for country in root.findall('country'):
	rank=country.find('rank').text
	name=country.get('name')
	print(rank,name)'''
'''
for v in root:
	print(v.tag)
	print(v.find('rank').text)'''
'''
for v in root.findall('./country/neighbor'):
	print(v.attrib)
'''

for v in root.findall('./country[@name="Panama"]/neighbor'):
	print(v.attrib)
