#!/usr/bin/python3
import xml.etree.ElementTree as ET;
from pprint import pprint;
emp_dict={};
xmlfil=ET.parse("emp.xml");
#print(xmlfil)
root =xmlfil.getroot();
#print(root)
#for emp_tag in root.findall("./employee"):
#for v in root.findall(".//*[@name='suresh']/year"):
for v in root.findall("./employee[@id='srm01']"):
	v.set('update','yes')
	print(v.attrib)	
xmlfil.write("emp.xml")
''' 
#	emp_id=emp_tag.get('id')
	#print(emp_id);
#for emp_tag in root.findall("./employee[@id='srm02']"):
	emp_id=emp_tag.get('id');
	username=emp_tag.find('name').text;
	expernce=emp_tag.find('experience').text;
	skills=emp_tag.find('skills').text;
	emp_dict[emp_id]={}
	emp_dict[emp_id]['username']=username;
	emp_dict[emp_id]['expernce']=expernce;
	emp_dict[emp_id]['skills']=skills;
pprint(emp_dict)
#print(emp_dict)
'''
