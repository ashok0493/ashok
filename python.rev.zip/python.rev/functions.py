#!/usr/bin/python3
"""def add(a,b):
	c=a+b;
	print(c)
	#return 'c'
	return""" 

"""print(add(10,20))       
add(10,2)
d=add(1,20)
print(d)
print(add(10,20))"""

"""def printdef(**karg):
	for i,j in karg.items():
		print(i,j);
	return
karg={'i':1,'j':2}
printdef(**karg)"""

"""import sys
def add(x,y):
	#x = 11
	#y = 12
	sum = X+y
	return
add(13,14)
print("sum")"""

"""#import sys
def add(x=6,y=4):
	sum=x+y
	print(sum)
	print("%s+%s=%s" %(x,y,sum))
	return sum
add()
print(add(20,15))"""

"""def change(a):
	print("before values",a);
	a[2]=30
	print("updated values",a);
	return a[2]
a=[1,2,3,4,5]
print(change(a))"""

"""def fun(x,y,*l,**d):
	print(x,y)
	print(d)
	sum = x+y
	for v in l:
		sum = sum + v
	return sum 
l=[2,7,8,9]
d={'a':1,'b':3}

print(fun(*l,**d))"""

"""def p(arg,*don):
	print(arg)
	for d in don:
		print(d)
	return
p(10)
p(10,15,20)"""

"""def add(*args):
	sum=0;
	for v in args:
	#	print(v);
		sum=sum+v;
		print(sum);
	return sum;
list1=[1,2,3,4];
list2=[5,6,7,8];
list3=list1 + list2;
print(add(*list3))"""
"""
def add(a=1,b=5):
	x=a+b
	print(x)
	return x
print(add(5))

def add(*s):
	sum=0
	for v in s:
		sum=sum+v
		print (sum)
	return
a=[1,2,3,4,5]
add(*a)
#add(*[1,2,3,4,5])
#add(1,2,3,4,5)
#a=[1,2,3,4,5]"""

"""def add(*mak):
	print(mak)
	return
add([1,2,3,4,5])
add(*[1,2,3,4,5])
add(1,2,3,4,5)"""

def add(**arg):
	for x,y in s.items():
		print(x,y)
	return (x,y)
s={'ashok':22,'siva':24,'srinu':27}
add(**s)

def add(**a):
	sum=0
	for v in a.values():
		sum=sum+v
		print("%s+%s=%s" %(sum,sum,v))
		print (v)
	return
add(a=1,b=2)
add(**{'a':1,'b':3})
