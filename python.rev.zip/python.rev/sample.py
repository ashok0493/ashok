#!/usr/bin/python3
l=['a','b','c','d']
s="ASHOK";
for v in s:
	print(ord(v),end='')
k=''.join(str(ord(c)) for c in s)
print(k)
j=[ord(c) for c in s]
print(j)
