#!/usr/bin/python3
k=input("enter number:")
f=open("file.csv1","r")
a=f.readline()
b=a.strip()
c=b.split(',')
d=f.readlines()
e={}
for f in d:
	g=f.strip()
	h=g.split(',')
	e[h[0]]={}
	e[h[0]][c[1]]=h[1]
	e[h[0]][c[2]]=h[2]
	e[h[0]][c[3]]=h[3]
	if k==h[0]:
		print(e[h[0]])
		break
else:
	print("not found")
#print(e)	
