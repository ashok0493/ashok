#!/usr/bin/python3
i=input("enter number:");
obj=open("filex.csv","r")
a=obj.readline()
#print(a)
b=a.strip()
c=b.split(',')
d=obj.readlines()
e={}
for v in d:
	f=v.strip()
	g=f.split(',')
	e[g[0]]={}
	e[g[0]][c[1]]=g[1]
	e[g[0]][c[2]]=g[2]
	e[g[0]][c[3]]=g[3]
	if i==g[0]:
		print(e[g[0]])
		break	
else:
	print("not found")
	

