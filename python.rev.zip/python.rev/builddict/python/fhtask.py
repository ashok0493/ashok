#!/usr/bin/python3
h=input("enter id:")
fob=open("file.csv","r")
a=fob.readline()
b=a.strip()
d=b.split(',')
e=fob.readlines()
s={}
for v in e:
	m=v.strip()
	n=m.split(',')
	s[n[0]]={}
	s[n[0]][d[1]]=n[1]
	s[n[0]][d[2]]=n[2]
	s[n[0]][d[3]]=n[3]
	if h==n[0]:
		print(s[n[0]])
		break
else:
	print("not found")
#print(s)


