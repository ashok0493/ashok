#!/usr/bin/python3
def fib(n):
	if n==0 or n==1:
		return n
	else:
		return fib(n-1)+fib(n-2)
n=int(input("enter number:"))
'''m=0
while m<n:
	print(fib(m))
	m=m+1'''
for v in range(n):
	print(fib(v))

