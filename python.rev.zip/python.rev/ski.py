#!/usr/bin/python3
l=[1,2,3,4,5,6,7,8,9,10]
i=1
for v in l:
	if v<4:
		print(v)	
	elif(v>6)or (v!=10):
		print(v)
		
		
