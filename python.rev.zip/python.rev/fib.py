#!/usr/bin/python3
f=[0,1]
for v in range(50):
	f.append(f[-1]+f[-2])	
print(f)
