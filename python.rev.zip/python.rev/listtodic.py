#!/usr/bin/python3
l=[1,2,3,4,5,6]
s=len(l)//2
#i=0
d={}
for v in range(0,len(l),2):
	print(v)
	d[l[v]]=l[v+1]
#	i=i+2
print(d)

