#!/usr/bin/python3
import re
str="this is my system mac id a4:17:31:a7:92:d3";
obj=re.findall(r'([0-9A-F]{1,2})\:([0-9A-F]{1,2})\:([0-9A-F]{1,2})\:([0-9A-F]{1,2})\:([\0-9A-F]{1,2})\:([0-9A-F]{1,2})',str);
print(obj)
