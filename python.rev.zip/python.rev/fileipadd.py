#!/usr/bin/perl
import os
import re
a=os.popen('ifconfig').read();
obj=re.findall(r'\d+\.\d+\.\d+\.\d+',a);
print(obj)
