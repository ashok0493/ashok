#!/usr/bin/python3
n=int(input("enter a number:"))
i=0
l=[1,2,3]
while i<n:
	k=int(input("enter number:"))
	l.append(k)
	i=i+1
print(l)
