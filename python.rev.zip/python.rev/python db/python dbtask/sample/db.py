#!/usr/bin/python3
import pymysql
pj=pymysql.connect(host='localhost',user='root',passwd='ashok',db='csv')
cur=pj.cursor()
cur.execute("show databases")
for i in cur.fetchall():
	print(i)
cur.execute("use "+input("enter database name :"))
cur.execute("show tables")
for j in cur.fetchall():
	print(j)
cur.execute("select * from "+input("enter table name :"))
dic={}
for i in cur.fetchall():
	dic[i[0]]=[i[1],i[2],i[3]]
print(dic)
	
	

