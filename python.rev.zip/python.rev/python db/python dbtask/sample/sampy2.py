#!/usr/bin/python3
import pymysql
ash=pymysql.connect(host='localhost',user='root',passwd='ashok',db='csv')
cur=ash.cursor()
sql="select * from srmemp"
try:
	cur.execute(sql)
	results=cur.fetchall()
	for r in results:
		eid=r[0]
		name=r[1]
		city=r[2]
		sal=r[3]
		print("eid={3},name={2},city={1},sal={0}".format(eid,name,city,sal))
		#print("eid=%s,name=%s,city=%s,sal=%s"%(eid,name,city,sal))
except:
	print("unable to fetch data")
