#!/usr/bin/python3
class myclass():
	"class is myclass"
	z=2
	def __init__(self,a,b):
		self.a=a
		self.b=b
	def add(self):
		return self.a+self.b+self.z
k=myclass(3,4)
print(k.add())
print(myclass.__name__)
print(myclass.__doc__)
print(myclass.__module__)
print(myclass.__bases__)
print(myclass.__dict__)
