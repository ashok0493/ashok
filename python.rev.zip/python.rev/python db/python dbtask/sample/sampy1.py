#!/usr/bin/python3
import pymysql
mi=pymysql.connect(host='localhost',user='root',passwd='ashok',db='csv')
cursor=mi.cursor()
#cursor.execute("insert into srmemp values(2,'nehra','kkd',35000),(3,'murty','annavaram',32000),(4,'battu','karapa',37000)")
#cursor.execute("create table srmemp(ID int(11) auto_increment primary key,NAME varchar(255) not null,CITY varchar(255) not null,SALARY int(11) not null)")
sql="update srmemp set SALARY=36000 where ID=5"
try:
	cursor.execute(sql)
	mi.commit()
except:
	mi.rollback()
	#print("unable to fetch")
