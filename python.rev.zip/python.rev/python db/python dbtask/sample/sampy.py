#!/usr/bin/python3
import pymysql
db=pymysql.connect(host='localhost',user='root',passwd='ashok',db='csv');
cur=db.cursor();
cur.execute("select * from csvfile")
results=cur.fetchall()
print(results)
