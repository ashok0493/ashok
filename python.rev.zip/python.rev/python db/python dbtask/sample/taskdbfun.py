#!/usr/bin/python3
import pymysql
def file(a):
	obj=open(a,"r+")
	k=obj.readline()
	s=k.strip()
	j=s.split(',')
	kp=pymysql.connect('localhost','root','ashok','csv')
	cur=kp.cursor()
	cur.execute("drop table if exists hitman")
	cur.execute("create table hitman({} int(11) not null,{} varchar(255) not null,{} varchar(255) not null,{} int(11) not null)".format(j[0],j[1],j[2],j[3]))
	n=obj.readlines()
	for v in n:
		h=v.strip()
		p=h.split(',')
		cur.execute("insert into hitman values({},'{}','{}',{})".format(p[0],p[1],p[2],p[3]))
	kp.commit()
	kp.close()
def dic():
	kp=pymysql.connect('localhost','root','ashok','csv')
	cur=kp.cursor()
	cur.execute("select * from hitman")
	dict={}
	for r in cur.fetchall():
		eid=r[0]
		dict[eid]={"name":r[1],"skills":r[2],"salary":r[3]}
	print(dict)
	kp.commit()
	kp.close()
def update():
	kp=pymysql.connect('localhost','root','ashok','csv')
	cur=kp.cursor()
	cur.execute("update hitman set NAME='sivaji' where ID=1")
	cur.execute("select * from hitman")
	for o in cur.fetchall():
		print(o)	
	kp.commit()
	kp.close()
if __name__=="__main__":
	file("file.csv")
	dic()
	update()
