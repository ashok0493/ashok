#!/usr/bin/python3
from taskdb import *;
file("file.csv")
dic()
update()
