#!/usr/bin/python3

import sys;
from pprint import pprint;
sys.path.append("/home/srm/python_modules");
##
#sudo apt-get install python3-pymysql
#> pip3 install pymysql -t /home/srm/python_modules

#from pymysql import connect;
import pymysql;

# Open database connection
conn = pymysql.connect(host="localhost",user="root",passwd="srm",db="pss",cursorclass=pymysql.cursors.DictCursor);
#conn = pymysql.connect(host="localhost",user="root",passwd="srm",db="pss");

# prepare a cursor object using cursor() method
cursor = conn.cursor()

##execute the query.
cursor.execute("select * from project");
##Build Dictionary
prj_dict = {};
result = cursor.fetchall();
for rown in result:
	chip = rown['chip'];
	rev  = rown['rev'];
	prj_dict[chip] = rev;

pprint(prj_dict);
# disconnect from server
conn.close()

