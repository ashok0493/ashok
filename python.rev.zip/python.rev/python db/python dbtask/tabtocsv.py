#!/usr/bin/python3
import pymysql
class csv:
	def __init__(self):
		self.db=pymysql.connect(host="localhost",user="root",password="ashok",database="csv");
		self.cur=self.db.cursor();
	def csvfile(self,a):
		obj=open(a,"w")
		j=[]
		self.cur.execute("desc india")
		for v in self.cur.fetchall():
			#print(v)
			#print(v[0])
			j.append(v[0])
		header=','.join(j)
		obj.write(header)
		obj.write("\n")
		self.cur.execute("select * from india")
		#h=[]
		for v in self.cur.fetchall():
			h=[]
			for k in v:
				h.append(str(k))
			lines=','.join(h)
			obj.write(lines)
			obj.write("\n")
obj=csv()
obj.csvfile("file4.csv")
