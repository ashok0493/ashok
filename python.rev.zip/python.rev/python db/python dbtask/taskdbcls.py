#!/usr/bin/python3
import pymysql
class ash:
	def __init__(self):
		self.kp=pymysql.connect('localhost','root','ashok','csv')
		self.cur=self.kp.cursor()
		self.cur.execute("select * from hitman")
	def file(self,a):
		obj=open(a,"r+")
		k=obj.readline()
		s=k.strip()
		j=s.split(',')
		self.cur.execute("drop table if exists hitman")
		self.cur.execute("create table hitman({} int(11) not null,{} varchar(255) not null,{} varchar(255) not null,{} int(11) not null)".format(j[0],j[1],j[2],j[3]))
		n=obj.readlines()
		for v in n:
			h=v.strip()
			p=h.split(',')
			self.cur.execute("insert into hitman values({},'{}','{}',{})".format(p[0],p[1],p[2],p[3]))
		self.kp.commit()
		self.kp.close()
	def dic(self):
		dict={}
		for r in self.cur.fetchall():
			eid=r[0]
			dict[eid]={"name":r[1],"skills":r[2],"salary":r[3]}
			print(dict)
		self.kp.commit()
		self.kp.close()
	def update(self):	
		self.cur.execute("update hitman set NAME='sivaji' where ID=1")
		self.cur.execute("select * from hitman")
		for o in self.cur.fetchall():
			print(o)	
		self.kp.commit()
		self.kp.close()


obj=ash()
obj.file('file.csv')
obj.dic()
obj.update()
#if __name__=="__main__":
#	file("file.csv")
	#dic()
	#update()
