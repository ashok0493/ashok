#!/usr/bin/python3
l=[1,2,3,4,5]
for v in list(range(10)):
	print(v)
