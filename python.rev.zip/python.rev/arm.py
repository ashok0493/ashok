'''import sys
s=sys.argv[1]
l=[]
#print(l)
for i in s:
	l.append(int(i)**len(s))
a=sum(l)
print(l)
if a==int(s):
	print("arm strong")
else:
	print("not")i'''

n=input("enter a number")
l=0
for i in n:
	l=l+(int(i)**len(n))
if l==int(n):
	print("armstrong")
else:
	print("not armstrong")
