#!/usr/bin/python3
from openpyxl import load_workbook
wb=load_workbook('empty_book.xlsx')
ws=wb['range names']
for row in ws:
	for v in row:
		print(v.value)
#print(wb)
