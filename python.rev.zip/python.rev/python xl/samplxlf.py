from openpyxl import load_workbook
wb=load_workbook("marks.xlsx")
#ws=wb["new title"]
ws=wb.active
for v in ws:
	for cell in v:
		print(cell.value)
