#!/usr/bin/python3
import pymysql
db=pymysql.connect('localhost','root','ashok','csv')
cur=db.cursor()
from openpyxl import load_workbook
wb=load_workbook("empty_book.xlsx")
#print(wb.get_sheet_names())
ws=wb.active
j=[]
g1=[]
i=0
for v in ws:
	g=[]
	if i>0:
		for k in v:
			g.append(k.value)
	else:
		for w in v:
			j.append(w.value)
	i=i+1
	if len(g)>0:
		g1.append(g)
m={}
for p in g1:
#	for r in p:
	m[p[0]]={}
	m[p[0]][j[1]]=p[1]
	m[p[0]][j[2]]=p[2]
	m[p[0]][j[3]]=p[3]
cur.execute("drop table if exists excel")
cur.execute("create table excel({} varchar(255) not null,{} varchar(255) not null,{} bigint(50) not null,{} char(25) not null)".format(j[0],j[1],j[2],j[3]))
for x in g1:
	cur.execute("insert into excel values('{}','{}',{},'{}')".format(x[0],x[1],x[2],x[3]))
db.commit()
'''
g=[]
i=0
for w in ws:
	if i>0:
		for h in w:
			g.append(h.value)
	i=i+1
print(g)'''
