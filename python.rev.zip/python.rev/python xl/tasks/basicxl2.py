#!/usr/bin/python3
from openpyxl.workbook import Workbook

header = [u'Name', u'Email', u'Mobile', u'Currentlocation']
new_data = [[u'name1', u'email1@yahoo.com', 9929283421.0, u'xxxx'], 
            [u'name2', u'email2@xyz.com', 9994191988.0, u'xxxxwb']]
wb = Workbook()

dest_filename = 'empty_book.xlsx'

ws1 = wb.active

ws1.title = "range names"

ws1.append(header)

for row in new_data:
    ws1.append(row)

wb.save(filename = dest_filename)
