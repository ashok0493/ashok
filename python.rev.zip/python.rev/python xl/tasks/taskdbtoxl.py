#!/usr/bin/python3
import pymysql
db=pymysql.connect('localhost','root','ashok','csv')
cur=db.cursor()
from openpyxl import Workbook
wb=Workbook()
ws=wb.active
cur.execute("desc excel")
r=[]
for v in cur.fetchall():
	r.append(v[0])
ws.append(r)
cur.execute("select * from excel")
j=[]
for k in cur.fetchall():
	j.append(list(k))
#print(j)
for n in j:
	ws.append(n)  
wb.save("dbdata.xlsx")



