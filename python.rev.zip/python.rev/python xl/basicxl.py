from openpyxl import load_workbook
wb=load_workbook('cal.xlsx')
print (wb.get_sheet_names())
