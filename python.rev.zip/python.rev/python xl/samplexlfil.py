from openpyxl import Workbook
wb=Workbook()
ws=wb.active
#print(ws)
ws1=wb.create_sheet("mysheet")
ws2=wb.create_sheet("mysheet1",1)
ws.title="new title"
#print(wb.get_sheet_names())
#or
ws=wb["new title"]
for r in ws:
	for cell in r:
		print(cell.value)
ws.sheet_properties.tabcolor="1072BA"
#print(wb)
#print(ws)
ws['A1']="names"
ws['A2']=12
ws['A3']=15

d=ws.cell(row=2,column=1,value=10)
#for j in ws:
#	for k in j:
#		print(k.value)
 
#for i in wb:
#	print(i.title)
#print(wb.sheetnames)
wb.save('marks.xlsx')
