#!/usr/bin/python3
l=[5,0,1,3,4,2,7,8]
l1=[]
while l:
	min=l[0]
	for x in l:
		if x<min:
			min=x
	l1.append(min)
	l.remove(min)
print(l1)
