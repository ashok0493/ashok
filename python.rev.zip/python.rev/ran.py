#!/usr/bin/python3
print(list(range(1,100,2)))
