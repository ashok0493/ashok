#!/usr/bin/python3
n=10
s=1
for v in range(5):
	print(' '*(n-v)+'*'*s)
	s=s+2

print(' '+'*'*4+' ')
for v in range(5):
	if v==2:
		print('*'*6)
		continue
	print('*'+'    '+'*')	
