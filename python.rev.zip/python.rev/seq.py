#!/usr/bin/python3
import random
list=[1,2,3,4,5]
print(random.choice(list))
random.seed(10)
print(random.random())
