#!/usr/bin/python3
import re
str="hello welcome to perl tutorial pdf are forwared to ashokkumar@gmail.com and siva330@gmail.com";
"""m=str.split()
#print(a)
l=[];
for v in a:
	v = re.findall(r'(\w+\@\w+\.\w+)',v)
	#m=v.group()
	l.append(v)
print(l)"""
fobj=re.findall(r'\w+\@\w+\.\w+',str)
print(fobj)
	
