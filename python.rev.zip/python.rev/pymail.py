#!/usr/bin/python3
import smptlib
sender ='ashokkumar.malipeddi2@gmail.com';
receivers=['ashokkumar.malipeddi2@gmail.com'];
message="hello this mail is sent from python smpt mail";
smptobj=smpt.lib.SMPT('localhost')
smptobj.sendmail(sender,receivers,message)
print("successfully sent email")
