#!/usr/bin/python3
'''
l=[1,2,3,[4,5,6,[7,8,9],10,11],[12,13,14,[15,16,17]],18]
s1=[]
s2=[]
s3=[]
for v in l:
	if type(v)==list:
		for i in v:
			if type(i)==list:
				for j in i:
					s1.append(j)
			else:
				s2.append(i)
	else:
		s3.append(v)
print(sum(s1+s2+s3))'''
def add(l):
	sum=0
	for v in l:
		if type(v)==list:
			sum=sum+add(v)
		else:
			sum=sum+v
	return sum
l=[1,2,3,[4,5,6,[7,8,9],10,11],[12,13,14,[15,16,17]],18]
print(add(l))
