#!/usr/bin/python3
import os;
print(os.listdir("/home/ashok/Desktop/python.rev/"))


