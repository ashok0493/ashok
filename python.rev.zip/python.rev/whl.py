#!/usr/bin/python3
count=1
while count<10:
	print(count)
	#break
	count=count+1
	#break
