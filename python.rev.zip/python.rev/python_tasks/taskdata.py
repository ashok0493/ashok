#!/usr/bin/python3
import re
fob=open("math.txt","r")
b=fob.readlines()
d={};
for a in b:
	if re.match(r'\w+\s*\{',a):
		k=a.split();
		#print(k[0])
	elif(re.match(r'\s*\}',a)):
		pass
		#d[k[0]]=s
	elif(re.match(r'\s*\d+\s*\d+\s*\d+',a)):
		j=a.split()
		s=0
		for v in j:
			s=s+int(v)
		#print(s)
		if k[0] in d:
			d[k[0]]+=s
		else:
			d[k[0]]=s
print(d)








































'''
fob=open("math.txt","r")
b=fob.readlines()
d={};
for a in b:
	if re.match(r'\w+\s*\{',a):
		k=a.split();
		#print(k[0])
	elif(re.match(r'\s*\}',a)):
		d[k[0]]=s
	elif(re.match(r'\s*\d+\s*\d+\s*\d+',a)):
		j=a.split()
		s=0
		for v in j:
			s=s+int(v)
			
print(d)
'''

