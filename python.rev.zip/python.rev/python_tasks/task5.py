#!/usr/bin/python3
l=[1,2,3,4,5,6,7,8,9,10]
n=[];
for v in l:
	if v%2==1:
		n.append(v)
	if len(n)==3:
		break
print(n)
