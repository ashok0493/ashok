#!/usr/bin/python3
import re
fobj=open("math.txt","r")
b=fobj.readlines()
dict1={}
for k in b:
	if (re.search(r'\w+\s*\{',k)):
		c=k.split()
		#print(c)
		open_flag=1
	elif (re.search(r'\s*\}',k)):
		open_flag=0
	elif (open_flag):
		j=k.split()
		m=0
		for v in j:
			m=m+int(v)
		if c[0] in dict1:
			dict1[c[0]]=dict1[c[0]]+m
		else: 
			dict1[c[0]]=m
print(dict1)
		
