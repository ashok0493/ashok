#!/usr/bin/python3
import re
fob=open("fileip.txt","r")
b=fob.readlines()
for v in b:
	c=re.search(r'(\d+)\.(\d+)\.(\d+)\.(\d+)',v)
	if (re.search(r'(\d+)\.(\d+)\.(\d+)\.(\d+)',v)):
		e=int(c.group(1))
		f=int(c.group(2))
		g=int(c.group(3))
		h=int(c.group(4))
		if e<255 and f<255 and g<255 and h<255:
			print(c.group())














'''	
	c=re.search(r'(\d+)\.(\d+)\.(\d+)\.(\d+)',v)
	if (re.search(r'\d+\.\d+\.\d+\.\d+',v)):
		k=c.group()
		s=k.split('.')
		for m in s:
			if int(m)>255:
				break
		else:
			print(k)
'''				
			
				
			
