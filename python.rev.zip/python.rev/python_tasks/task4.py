#!/usr/bin/python3
i=0
s=0
while i<10:
	if i%2==1:
		print(i);
		s+=1;
	if s==3:
		break
	i=i+1 
