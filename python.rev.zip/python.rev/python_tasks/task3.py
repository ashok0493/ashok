#!/usr/bin/python3
l=[1,2,2,3,4,4,5,6,6,7]
d=[]
for v in l:
	if v not in d:
		g=d.append(v)
print(d)
