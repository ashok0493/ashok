#!/usr/bin/python3
fob=open("filex.txt","r")
c=fob.readlines()
#print(c)
k={}
for v in c:
	d=v.split(' ')
	for p in d:
		if p in k:
			k[p]=k[p]+1
		else:
			k[p]=1
print(k['venky'])
			 


	

