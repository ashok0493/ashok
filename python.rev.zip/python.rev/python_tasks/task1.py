#!/usr/bin/python3
fobj=open("file.txt","r")
w=fobj.readlines()
y=len(w)
print(y,"total length of lines")
sum=0
for v in w:
	x=v.split(',')
	sum=sum+len(x)
print(sum,"total length of words")
	
	

