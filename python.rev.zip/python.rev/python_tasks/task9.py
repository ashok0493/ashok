#!/usr/bin/python3
import re
f=open("ip.txt","r")
b=f.readlines()
for v in b:
	c=re.findall(r'\d+\.\d+\.\d+\.\d+',v)
	for v in c:
		d=re.search(r'(\d+)\.(\d+)\.(\d+)\.(\d+)',v)
		s=int(d.group(1))
		p=int(d.group(2))
		r=int(d.group(3))
		m=int(d.group(4))
		if s<255 and p<255 and r<255 and m<255:
			print(d.group())
