#!/usr/bin/python3
str="this is string example wow!!!"
asg=str.split('w');
print(asg)
