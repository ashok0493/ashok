#!/usr/bin/python3
for i in range(1,11):
	for v in range(1,11):
		k=i*v
		print(k,end=' ')
	print()
