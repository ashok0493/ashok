#!/usr/bin/python3
import webbrowser
import time
import math
#import urllib.request
#webbrowser.open("chromium-browser")
#to open convinent browser with particular site
k=webbrowser.get('chromium-browser').open("https://www.google.com")
#time.sleep(10)
#k.kill()
