#!/usr/bin/perl
$a=$ARGV[0];
@b=split(',',$a);
foreach $k (@b){
	print($k);
}

