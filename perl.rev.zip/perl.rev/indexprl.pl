#!/usr/bin/perl
    use strict;
    #use warnings;
    #use 5.010;
    use List::MoreUtils qw(first_index);
     
    my @planets = qw(
       Mercury
       Venus
       Earth
       Mars
       Ceres
       Jupiter
       Saturn
       Uranus
       Neptune
       Pluto
       Charon
    );
     print("first_index");

    print( first_index { $_ eq 'Mars' } @planets);
