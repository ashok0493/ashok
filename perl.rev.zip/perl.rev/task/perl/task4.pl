#!/usr/bin/perl
@ar=(1,2,3,4,5,6,7,8,9,10);
$i=0;
foreach $v (@ar){
	if ($v%2==1){
		print"$v\n";
	#	$i=$i+1;
	}
	if ($i==3){
		last
	}
	$i=$i+1;
}
