#!/usr/bin/perl
open(data,"<filex1.txt");
=head
while ($line=<data>){
	print"$line";
	$line1=<data>;
}
=cut


@l=<data>;
$i=0;
foreach $v (@l){
	@k=split(' ',$v);
	
	foreach $s (@k){
		if ($i%2==1){
			print"$s\n";
		}
		$i=$i+1;
	}	  
}	
