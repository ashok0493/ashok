#!/usr/bin/perl
=head
$str="ip addresses of srmicro is 192.168.1.5 and 192.168.1.18 connected to lan 192.168.1.255";
@b=split(' ',$str);
foreach $v (@b){
	if ($v=~/\d+\.\d+\.\d+\.\d+/){
		print"$&\n";
	}
}
=cut
open(data,"<ip.txt");
@line=<data>;
foreach $v (@line){
	@c=split(' ',$v);
	foreach $g (@c){
		if ($g=~/(\d)+\.(\d+)\.(\d+)\.(\d+)/){
			if (($1<255)&&($2<255)&&($3<255)&&($4<255)){
				print"$&\n";
			}
			else{
				print"invalid\n";
			}
		}	
	}
}

