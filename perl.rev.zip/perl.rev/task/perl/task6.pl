#!/usr/bin/perl
use Data::Dumper;
%h=();
@array=(1,2,2,2,3,4,5,5,6,7,7,8,8,8,9);
foreach $s (@array){
	$h{$s}=$h{$s}+1;
}
@arr=keys %h;
print(@arr);
#print"$h{5}\n";
print Dumper(\%h);
