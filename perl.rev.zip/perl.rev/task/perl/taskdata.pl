#!/usr/bin/perl
use Data::Dumper;
open(IN,"<math.txt");
%hash=();
while ($line=<IN>){
	if ($line=~/(\w+)\s*\{/){
		$open_flag=1;
		@s=split('\s+',$line);
	}
	elsif ($line=~/\s*\}/){
		$open_flag=0;
		#print"$c\n";
		$hash{@s[0]}=$c;
		$c=0
	}
	elsif ($open_flag){
		@m=split('\s+',$line);
		foreach $v (@m){
			$c=$c+$v;
		}print"$c\n";
	}	
}
print Dumper(\%hash);
