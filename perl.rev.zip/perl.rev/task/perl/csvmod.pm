#!/usr/bin/perl
package csvmod;
use Data::Dumper;
use strict;
use warnings;
use vars qw(%h @ISA @EXPORT);
require Exporter;
@ISA=qw(Exporter);
@EXPORT=qw(csvfile empname);
sub csvfile{
	%h=();
	open(my $data,"<$_[0]");
	my $hl=<$data>;
	my @a=split(',',$hl);
	my @ln=<$data>;
	foreach my $k (@ln){
		my @j=split(',',$k);
		$h{$j[0]}=[$j[1],$j[2],$j[3]];
	}
}
sub empname{
	my $username=$_[0];
	if (exists($h{$username})){
		print("emp_name:",$username,"\n");
		print("skill :",$h{$username}->[0],"\n");
		print("sal :",$h{$username}->[1],"\n");
		print("cantno :",$h{$username}->[2],"\n");
	}
	else{
		print("emp_id not found\n");
		print("required emp_id's are");
	}
}
1; 
