#!/usr/bin/perl
sub printm{
	$n=scalar(@_);
	$sum=0;
	foreach $v (@_){
		#print"$sum\n";
		$sum=$sum+$v;
	}print"$sum\n";
	return 
}
printm(10,20,30,40);
