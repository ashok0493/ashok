#!/usr/bin/perl
use strict;
use warnings;
use csvmod;
use Getopt::Long;
my $csv_file_name;
my $username;
my $help;
GetOptions("csvfile=s"=>\$csv_file_name,
				   "usern=s"=>\$username,
					 "h|help"=>\$help
) or die("error in command line arguments\n");
if ($help){
	&usage();
}
if (not defined($csv_file_name)){
	print"-E- please input csv file\n";
	exit;
}
if (not defined($username)){
	print"-E- please input user name\n";
	exit;
}
if (-e $csv_file_name){
	csvfile($csv_file_name);
}else{
	print"-E- '$csv_file_name' file doesnt exists";
	exit;
}
empname("$username");
sub usage{
	print"$0\n";
	print"Script options\n";
	print" csv_file;provide input csv file.\n";
	print" user_id: provide user id\n";
	print"Ex:$0 -c csv_file -u empname\n";
	exit;
}
