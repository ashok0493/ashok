#!/usr/bin/perl
use Data::Dumper;
open(file,"<filex.txt");
@line=<file>;
#print"@line\n";
%h=();
foreach $v (@line){
	@m=split(' ',$v);
	foreach $c (@m){
		if (exists $h{$c}){
			$h{$c}+=1;
		}
			else{
				$h{$c}=1;
		}
	}
}
print Dumper (\%h);
