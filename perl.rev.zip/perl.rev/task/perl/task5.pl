#!/usr/bin/perl
@l=(1,2,3,4,5,6,7,8,9);
@s=();
$c=@s;
foreach $n (@l){
	if ($n%2==1){
		push(@s,$n);
	
		if ($c==3){
			last;
		}

	}
}
print"@s\n";

















=head
$i=1;
$v=0;
while ($i < 10){
	if ($i%2==1){
		print"$i\n";
		$v=$v+1;
	}
	if ($v==3){
		last
	}
	$i=$i+1;
}
=cut
