#!/usr/bin/perl
=head
%h=('a'=>3,'b'=>4,'c'=>5);
foreach $v (keys (%h)){
	print"$v:$h{$v}";
}
while (($k,$v)=each (%h)){
	print"$k:$v\n";
}

$href={'a'=>6,'b'=>7,'c'=>8};
foreach $v (keys (%{$href})){
	print"$v:$href->{$v}\n";
}

#foreach $v (keys (${@href})){ #to dereference %{} is used to derefnce it not used scalar and array 
#	print"$v:$href->{$v}\n";
#}
=cut
$href={'a'=>5,'b'=>6,'c'=>7};
while (($m,$n)=each %{$href}){
	print"$m:$n\n";
}
