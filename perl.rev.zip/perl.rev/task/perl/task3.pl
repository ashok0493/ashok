#!/usr/bin/perl
@arr=(1,2,2,3,3,4,5,5,6,7,7,8,1,1,1,3,3,3,6,6,6,7,7,9,9,9,10,10);
@uni=();
foreach $c (@arr){
	if ($c ne @uni){
		push(@uni,$c);
	}
}
print"@uni\n";
