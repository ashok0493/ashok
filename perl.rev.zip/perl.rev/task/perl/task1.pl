#!/usr/bin/perl
open(data,"<file.txt");
@lin=<data>; 
$v=@lin;
print"$v\n";
$count=0;
foreach $n (@lin){
	$m=split(',',$n);
	$count=$count+$m;
} 
print"$count\n";

