#!/usr/bin/perl
open(data,"<fileip.txt");
@line=<data>;
foreach $l (@line){
	if ($l=~/(\d+)\.(\d+)\.(\d+)\.(\d+)/){
		if (($1<255) & ($2<255) & ($3<255) & ($4<255)){
			print"$&\n";
		}
	}

}
