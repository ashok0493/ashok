#!/usr/bin/python3
fob=open("foo.txt","wb")
print("name of file:",fob.name)
print("mode of file:",fob.mode)
print("close or open:",fob.closed)
fo.close()
