#!/usr/bin/perl
$v=123456;
@a=split("",$v);
$b=$a[2];
#print"$b";
$c=<>;
$d=$c;
print"$d";
if($b == $d){
	print"matched\n";
}else{
	print"notmatched"
}
