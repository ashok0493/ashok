#!/usr/bin/perl
$str='hello world this is perl and 9030196569 and ashok@gmail.com and ashok2@gmail.com and sivaji@gmail.com';
#$str =~ m/\w+\@\w+\.\w+/;
#$str=~m/[a-z]+\@+[a-z]+\.[a-z]+/;
#$str=~m/[^whl]/;
#print"$&\n"
#$str=~m/\w{10,11}/;
#$str=~m/stag|perl/;
#print"$&\n"
#$ash="hello topic is about split in perl";
@std=split(' ',$str);
@stm=();
#print"$std[0]"
foreach $_ (@std){
	$_=~ /\w+\@\w+\.\w+/;
#	push(@stm,$&);
	print"$&\n";
#	push(@stm,$&);
}
#print("@stm")
