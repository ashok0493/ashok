#!/usr/bin/perl
$ash="hello topic is about split in perl";
@str=split(' ',$ash);
print"$str[1]\n"
