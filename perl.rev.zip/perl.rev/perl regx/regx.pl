#!/usr/bin/perl
$line="to match the charaacter of the given sentence";
#$line="foood";
#$line =~ /char/;
#print"$'";
#$line=~ s/match/replace/;
$line=~ tr/a/o/s;
print"$line"
