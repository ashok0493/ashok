#!/usr/bin/perl
$mak='hi this is srmicro mailids i ashok@gmail.com siva@gmail.com srinu@gmail.com';
@ash=split(' ',$mak);
@arr=();
foreach $_ (@ash){
	$_=~ /\w+\@\w+\.\w+/;
	push(@arr,$&);
	print"$&\n"
}
print"@arr\n"
