#!/usr/bin/perl
sub hsh{
	%k=%{$h};
	@s=@{$a};
	print"@s\n";
	foreach $j (keys(%k)){
		print"$j=>$k{$j}";
	}
}
$h={'a'=>10,'b'=>20};
$a=[1,2,3,4,5];
hsh($h,$a);
