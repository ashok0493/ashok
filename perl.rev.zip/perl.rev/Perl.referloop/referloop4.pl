#!/usr/bin/perl
$v=[1,2,3,[4,5,6],7,8,9,[10,11,12],[14,15,16],17,18,19,{'c'=>[6,6,6,6,6,6],'d'=>[1,2,3,4,5,6]}];
#print"$v->[15]";
foreach $n (@{$v}){
	if (ref($n) eq "ARRAY"){
		print"@{$n}\n";
	}
}








=head
	elsif (ref($n) eq "HASH"){
		foreach $m (keys(%{$v->[12]}){
			print"$m=>@{$v->[12]->{$m}}\n";
		}
	}
	else{
		print"$n\n";
		}
}
=pod	

