#!/usr/bin/perl
$d=[1,2,3,4,{'a'=>[15,16,17],'b'=>[20,20,{'c'=>[21,2,25],'d'=>[50,51]},50,50],'e'=>["powerstar",'in','katamarayudu']},5,6,7];
foreach $r (@{$d}){
	if ($r ne $d->[4]){
		print"$r\n";
	}
	elsif ($d->[4]){
		foreach $s (keys(%{$d->[4]})){
			if ($s ne 'b'){
				print"$s=>@{$d->[4]{$s}}\n";
			}
			elsif (ref($s) ne "HASH"){
				foreach $t (@{$d->[4]->{'b'}}){
					if (ref($t) ne "HASH"){
						print"$t\n";
					}
					elsif (ref($t) eq "HASH"){
						while (($k,$v)=each(%{$d->[4]->{'b'}->[2]})){
							print"$k=>@{$v}\n";
						}
					}else{
						print"\n";
						}
				}
			}
			else{
				print"\n";
				}
		}
	}else{
		print"\n";
	}
}
