#!/usr/bin/perl
$p=[1,2,3,{'a'=>[4,5,6,{'b'=>[7,8,9],'c'=>10},11,12]},13,14,15];
foreach $a (@{$p}){
	if ($a ne $p->[3]){
		print"$a\n";
	}
	elsif (ref($a) eq "HASH"){
		foreach $b (@{$p->[3]->{'a'}}){
			if ($b ne $p->[3]->{'a'}->[3]){
				print"a=>$b\n";
			}
			elsif (ref($b) eq "HASH"){
				foreach $c (keys(%{$p->[3]->{'a'}->[3]})){
					if ($c ne 'c'){
						print"$c=>@{$p->[3]->{'a'}->[3]{$c}}\n";
					}
					else{
						print"$c=>$p->[3]->{'a'}->[3]{$c}\n";
					}
				}
			}
			else{
				print"\n";
				}
				
		}
	}
	else{
			print"\n";
		}
}

