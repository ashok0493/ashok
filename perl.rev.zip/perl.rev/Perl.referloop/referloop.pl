#!/usr/bin/perl
print("keys values\n");
%has=('a'=>[1,2,3],'b'=>[4,5,{'c'=>[6,7,8]}],'d'=>9,'e'=>[10,11,12]);
foreach $a (keys(%has)){
	if ($a=>@{$has{$a}}){
		print"$a=>@{$has{$a}}\n";
	}
	else{
		print"$a=>$has{$a}\n";
	}

}
%b=%{$has{'b'}->[2]};
foreach $n (keys(%b)){
	print"$n,@{$b{$n}}\n";
}

