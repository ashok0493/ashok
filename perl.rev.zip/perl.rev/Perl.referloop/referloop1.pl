#!/usr/bin/perl
$a=[1,2,3,4,5,{'a'=>[6,7,8],'b'=>{'c'=>[9,10,11],'e'=>[12,13]}},14,15];
foreach $p (@{$a}){
	if ($p ne $a->[5]){
		print"$p\n";
	}
	elsif (ref($p) eq "HASH"){
	
	#elsif ($p){
		foreach $b (keys(%{$a->[5]})){
			if ($b eq a){
				print"a=>@{$a->[5]->{$b}}\n";
			}
			else{
					foreach $c (keys(%{$a->[5]->{'b'}})){
							print"$c=>@{$a->[5]->{'b'}->{$c}}\n";
					}
					}
			}
		}	
		else{
				print"\n";
			}				
}
