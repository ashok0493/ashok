#!/usr/bin/perl

sub add{
	@a=@{$_[0]};
	%h=%{$_[1]};
	foreach $b (keys(%h)){
		print"$b=>$h{$b}";
}
}
$a=[1,2,3,4,5];
$s={'a'=>1,'b'=>2};
add($a,$s);

























=head
sub add{
	@a=@{$_[0]};
	print @a;
return;
}
$a=[1,2,3,4,5];
add($a);












=head
sub add{
	$sum=0;
foreach $a(@_){
		$sum=$sum+$a;
	print"$sum";
}
	return;
}
@a=(1,2,3,4,5);
add(@a);
=head
sub add{
	$ad=$_[0]+$_[1];
	print"$ad\n";
	
	return;
}
add(10,20);




=pod
$a=1;
@ar=(1,2,3,4,5);
%h=('m'=>15,'n'=>25,'p'=>35);

avg(\$a,\@ar,\%h);
#avg(10,2,30,40);
