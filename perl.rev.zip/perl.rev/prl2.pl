#!/usr/bin/perl
%has=('john'=>23,'kumar'=>24,'cena'=>25);
=head
foreach $a (keys (%has)){
	print("keys:$a,values:$has{$a}\n")
}
=cut
while (($keys,$values) =each(%has)){
	print"$keys,$values\n";
}

