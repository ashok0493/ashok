#!/usr/bin/perl
#use strict;
use Data::Dumper;
my @a=(1,2,3,4,5);
my @a1=(6,7,8,9,10);
my @a2=(1,7,2,3,4,5);
my %uniq_arr;
for my $each(@a,@a1,@a2){
#	$uniq_arr{$each}++;
	if (exists $uniq_arr{$each}){
		$uniq_arr{$each}+=1;
}
else{
$uniq_arr{$each}=1;
}
}
print Dumper(\%uniq_arr);
#grep to find highest values
=head

@a=(1,2,3,8,7,9);
@b=grep{$_>3}@a;
print(@b);

my @names = qw(Foo Bar Baz);
my $visitor = <STDIN>;
chomp $visitor;
if (grep { $visitor eq $_ } @names) {
   print "Visitor $visitor is in the guest list\n";
} else {
   print "Visitor $visitor is NOT in the guest list\n";
}
print"$^0\n";

@m=(1,2,2,3,4,5);
my %h;
$h{$_}=0 for (@m);
print(%h);
print("\n");
print $_ foreach (@m);

#all directories
opendir(DIR,'.');
my @files=readdir(DIR);
closedir(DIR);
#print(@files);
foreach my $file(@files){
	print"$file\n";
}
=cut

$sum =0;
 
$count = 0;
 
print "Enter number: ";
 
$num = <>;
 
chomp($num);
 
while ($num >= 0)
 
{
 
$count++;
 
$sum += $num;
 
print "Enter another number: ";
 
$num = <>;
 
chomp($num);
 
}
 
print "$count numbers were entered\n";
 
if ($count > 0)
 
{
 
print "The average is ",$sum/$count,"\n";
 
}
 
exit(0);






























































$test="1234tyyyy456";
$number=($test=~ tr/[0-9]/[0-9]/);
print"$number";





