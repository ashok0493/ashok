#!/usr/bin/perl
my $input=<STDIN>;
use Data::Dumper;
open(data,"<file.csv1");
$line=<data>;
@l=split(',',$line);
@lin=<data>;
%h=();

foreach $v (@lin){
	@li=split(',',$v);
	$h{@li[0]}={};
	$h{@li[0]}->{@l[1]}=@li[1];
	$h{@li[0]}->{@l[2]}=@li[2];
	$h{@li[0]}->{@l[3]}=@li[3];
#	if ($input==@li[0]){
#		print Dumper (\%h);
#	}
}
	
print Dumper(\%h);



	

	

