#!/usr/bin/perl
$v=<STDIN>;
use Data::Dumper;
open(data,"<file2.csv");
$l=<data>;
@lines=<data>;
@a=split(',',$l);
#print"@a\n";
%hash=();
foreach $b (@lines){
	@c=split(',',$b);
	$hash{@c[0]}={};
	$hash{@c[0]}->{@a[1]}=@c[1];
	$hash{@c[0]}->{@a[2]}=@c[2];
	$hash{@c[0]}->{@a[3]}=@c[3];
  if ($v == $hash{@c[0]}){
		print Dumper ($hash{@c[0]});
	}
}


=pod


	if ($v==@c[0]){
		print Dumper ($hash{@c[0]});
		last;
	}
}
unless($v==@c[0]){

	print"not found records\n";
}
