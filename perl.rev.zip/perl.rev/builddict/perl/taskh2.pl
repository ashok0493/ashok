#!/usr/bin/perl
$o=<STDIN>;
use Data::Dumper;
open(file,"<file.csv2.pl");
$line=<file>;
@li=<file>;
@s=split(',',$line);
%h=();
foreach $m (@li){
	@k=split(',',$m);
	$h{@k[0]}={};
	$h{@k[0]}->{@s[1]}=@k[1];
	$h{@k[0]}->{@s[2]}=@k[2];
	$h{@k[0]}->{@s[3]}=@k[3];
}
	
print Dumper(\%h);

