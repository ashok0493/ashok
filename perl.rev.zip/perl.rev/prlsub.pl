#!/usr/bin/perl
sub hsh{
	%h=%{$_[0]};
	foreach $k (keys(%h)){
		$v=$h{$k};
		print($k,$v);
	}
	return
}
hsh({'a'=>10,'b'=>20,'c'=>30});
hsh({'d'=>40,'e'=>50})
