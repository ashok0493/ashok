#!/usr/bin/perl
use strict;
use warnings;
use Data::Dumper;
use task9;#load module
use Getopt::Long;
my $obj=new task9();#constructor function calling
my $csvfile;
my $emp_id;
my $help;
GetOptions("csvfile=s"=>\$csvfile, #string
						"emp_id=s" =>\$emp_id,#string
						"h|help"=>\$help) or die("error in command line argument\n");
if($help){
	&usage();
	}
if(not defined($csvfile)){
	print("-E enter csv file");
	exit;
	}
if (not defined($emp_id)){
	print("-E enter emp_id");
	exit;
	}
if (-e $csvfile){
	$obj->csvreader($csvfile);
	}
else{
	print("csv file does not exists");
	exit;
	}
$obj->emp_data($emp_id);
#print Dumper ($obj);	
sub usage{
	print"$0\n";
	print"script options\n";
	print"    csvfile:provide input csv file.\n";
	print"    emp_id: provide input emp_id.\n";
	print"    h(or)help:print halp Documentation.\n\n";
	print"Ex: $0 -c csvfile -e sr01\n";
	exit:
	}#end sub
