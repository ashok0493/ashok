#!/usr/bin/perl
package task9;
use strict;
use warnings;
sub new{ 
	my $class=shift;##constructor module
	my $self={hash=>{}};
	bless $self,$class;
	return $self;
	}
sub csvreader{
	my$self=shift;
	open(my $data,"<@_"); ##csv file read;
	my $line=<$data>; #header line read;
	my @lsp=split(',',$line);
	my @lines=<$data>;
	close($data);
	foreach my $a (@lines){
		my @lssp=split(',',$a);
		$self->{hash}->{$lssp[0]}={};
		$self->{hash}->{$lssp[0]}->{$lsp[1]}=$lssp[1];
		$self->{hash}->{$lssp[0]}->{$lsp[2]}=$lssp[2];

		}#end loop
	}#end sub
sub emp_data{	
	my $self=shift;
	if (exists($self->{hash}->{$_[0]})){
		print("emp_id  : ",$_[0],"\n");
		foreach my $s (keys(%{$self->{hash}->{$_[0]}})){
			print($s,"  :  ", $self->{hash}->{$_[0]}->{$s},"\n");
			}#end foreach
		print("\n");
		}#end if
	else{
		print($_[0],"  :emp_id is not found\n");
		print("##---------required emp_id's are : sr01 to sr04------------##\n\n");
		}#end else

	}#end sub

1;


	
#my $obj=new sivao3();	
#$obj->csvreader($ARGV[0]);
#$obj->emp_data($ARGV[1]);
##print  Dumper ($obj);
