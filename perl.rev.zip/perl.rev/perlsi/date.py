#!/usr/bin/python3
day=["sunday","monday","tuesday","wednesday","thursday","friday","saturday"]
month={1:0,2:3,3:3,4:6,5:1,6:4,7:6,8:2,9:5,10:0,11:3,12:5}
cen={10:2,11:0,12:6,13:4,14:2,15:0,16:6,17:4,18:2,19:0,20:6,21:4,22:2,23:0,24:6,25:4}
mon=int(input("enter month:"))
date=int(input("enter date:"))
year=input("enter year:")
century=int(input("enter century:"))
m=int(year[-2:])//4
s=int(year[-2:])+m+month[mon]+date+cen[century]
a=s%7
if (year):
	if (((int(year))%4)==0):
		a=a-1
		print(day[a])
	else:
		print(day[a])

