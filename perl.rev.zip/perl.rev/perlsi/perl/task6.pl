#!/usr/bin/perl
use strict;
use warnings;
use Getopt::Long;
use lib ("/home/srm/Desktop");#module file path is taken in lib
use csvmodtask6;#load mobule
my $csv_file_name;
my $user_id;
my $help;
GetOptions("csv_file=s" => \$csv_file_name,    # csv file
           "user_id=s"   => \$user_id,      # user id
           "h|help"   => \$help,      # print help
) or die("Error in command line arguments\n");

if($help) {
    &usage();#'&' means non conditoinal in functions
} ##end if

if(not defined($csv_file_name)) {
  print "-E- Please input csv file\n";
  exit;
} ##end if

if(not defined($user_id)) {
  print "-E- Please input user_id\n";
  exit;
} ##end if
if (-e $csv_file_name) {
  csvreader($csv_file_name);
} else {
  print "-E- '$csv_file_name' file does not exists";
  exit;
} ##end if
##check for user id
emp_data($user_id);
#-----------------------------------------------------------
#Function: usage
#Description: This script is used to print help.
#Input:Nil
#Output:Nil
#-----------------------------------------------------------
sub usage {
  print "$0\n";
  print "Script Options\n";
  print "   csv_file: Provide Input csv file.\n";
  print "   user_id: Provide user id.\n";
  print "   h: Print Help Documentation.\n\n";
  print "Ex: $0 -c csv_file -u SRM001\n";
  exit;
} ##end sub   











=pod
#csvreader("/home/srm/Desktop/f2.csv");
#emp_data(@ARGV);#@ARGV means command line argument
#emp_data(@ARGV);#@ARGV means command line argument
#siva::csvreader("/home/srm/Desktop/f2.csv");
#siva1::emp_data(@ARGV);#@ARGV means command line argument
#siva1::emp_data(@ARGV);#@ARGV means command line argument
