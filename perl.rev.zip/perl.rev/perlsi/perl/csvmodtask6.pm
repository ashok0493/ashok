#!/usr/bin/perl
package csvmodtask6;
use strict;
use warnings;
#use Data::Dumper;
use vars qw(%hash @spl @ISA @EXPORT);
require Exporter;
@ISA=qw(Exporter);
@EXPORT=qw(csvreader emp_data);
sub csvreader{
    %hash=();
    open(my $data,"<$_[0]");
    my $headerline=<$data>;#header line are read
    @spl=split(',',$headerline);#header line are split
    my @lines=<$data>;#employee data lines are read
    foreach my $a (@lines){
        my @sp=split(',',$a);#empdata split in each itaration 
        $hash{$sp[0]}=[$sp[1],$sp[2],$sp[3]] ;
    }#end in foreach loop
}#end sub

sub emp_data {
    my $user_id = $_[0];
    if (exists($hash{$user_id})) {
        print("emp_id           :", $user_id,"\n");
        print("emp_name         :",$hash{$user_id}->[0],"\n");
        print("emp_salary       :",$hash{$user_id}->[1],"\n");
        print("emp_phone_number :",$hash{$user_id}->[2]);
        }   ##end if
    else{ 
        print("emp_id is not found\n");
        print("required emp_id's are : sr01 to sr10\n");
    }
}   ##end sub
1;#positive value is return











=pod
#end package siva

#package siva1;
#use Data::Dumper;
#sub emp_data{
#    if (exists($siva::hash{$_[0]})){
#        print Dumper($siva::hash{$_[0]});# calling hash in package siva
#    }
#    else{
#        print "enter employee number is not found\n";
#        print "required employee numbers are sr01 to sr10\n";    
#    }
#    return;
#}
# positive intiger is return
