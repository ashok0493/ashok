#!/usr/bin/perl
package csvfil;
use DBI; 
use strict;
use warnings;
sub new{
	my $class=shift;
	my $self={_db=>DBI->connect("DBI:mysql:database=csv","root","ashok")};
	bless $self,$class;
	return $self;
}
sub csv{
	my $self=shift;
	open(my $data,"<@_");
	my $l=<$data>;
	my @m=split /,/,$l;
	my $sth=$self->{_db}->do("drop table if exists srmicro");
	$sth=$self->{_db}->prepare("create table srmicro($m[0] int(11) not null,$m[1] varchar(255) not null,$m[2] int(11) not null,$m[3] int(11) not null)");
	$sth->execute();
	while (my $lin=<$data>){
	my @k=split(',',$lin);
	$sth=$self->{_db}->prepare("insert into srmicro values (?,?,?,?)");
		$sth->execute($k[0],$k[1],$k[2],$k[3]);
	}
}
sub hsh{
	my $self=shift;
	my $sth=$self->{_db}->prepare("select * from srmicro");
	$sth->execute();
	print("\t=====hash====\n");
	while (my $ref=$sth->fetchrow_hashref()){
		print("ID=>$ref->{'ID'}\n");
		print("NAME=>$ref->{'NAME'}\n");
		print("AGE=>$ref->{'AGE'}\n");
		print("SALARY=>$ref->{'SALARY'}\n");
		print("\n");
	}
}
sub update{
	my $self=shift;
	my $sth=$self->{_db}->do("update srmicro set NAME='rajesh' where ID=4");
	$sth=$self->{_db}->prepare("select * from srmicro");
	$sth->execute();
	print("\t====update===\n");
	while (my @arr=$sth->fetchrow_array()){
		print("@arr\n");
	}
}	
my $obj=new csvfil();
$obj->csv("file.csv");
$obj->hsh();
$obj->update();

