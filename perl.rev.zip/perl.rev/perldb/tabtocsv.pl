#!/usr/bin/perl
use DBI;
package file;
sub csvfile{
	my $class=shift;
	my $self={_db=>DBI->connect("DBI:mysql:database=csv","root","ashok")};
	bless $self,$class;
	return $self;
}
sub data{
	my $self=shift;
	open(my $dat,">@_");
	my $sth=$self->{_db}->prepare("desc india");
	$sth->execute();
	@ar=();
	while (@row=$sth->fetchrow_array()){
	push(@ar,"$row[0]");
	}
	$headr=join(",",@ar);
	print $dat ("$headr","\n");
	my $sth=$self->{_db}->prepare("select * from india");
	$sth->execute();
	while (my @row =$sth->fetchrow_array()){
		my $table_data=join(",",@row);
		print $dat("$table_data","\n");
	}
}	
$obj=csvfile file();
$obj->data("file3.csv");
