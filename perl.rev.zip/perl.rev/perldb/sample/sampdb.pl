#!/usr/bin/perl
use Data::Dumper;
use DBI;
use strict;
my $db=DBI->connect("DBI:mysql:database=csv","root","ashok");
#my $db=DBI->connect("DBI:mysql:database=csv;host=localhost","root","ashok");
my $sth=$db->prepare("select * from csvfile");
$sth->execute();
#print("name=$ref->{'NAME'}");
while (my $ref=$sth->fetchrow_hashref()){
	print"id=$ref->{'ID'},name=$ref->{'NAME'}\n";
}
$sth->finish();
#print Dumper($ref);

#my $db->commit();
