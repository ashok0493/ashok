#!/usr/bin/perl
use strict;
use DBI;
my $db=DBI->connect("DBI:mysql:database=csv;host=localhost","root","ashok");
#my $h=$db->prepare("create table india (number int(11) not null,name varchar(255) not null,salary int(11) not null)");
#$db->do("insert into india values(1,'sehwag',100000),(2,'sachin',200000),(3,'dravid',150000),(4,'laksham',125000)");
#my $sth=$db->prepare("select * from india");
#my $number='7';
#my $name='harbajan';
#my $salary='1950000';
#my $sth=$db->prepare("insert into india values(?,?,?)");
my $sth=$db->prepare("update india set name='zaheer' where number='7'");
#$sth->execute($number,$name,$salary);
print("number of columns updated :"+ $sth->rows);
$sth->execute();
#$sth->finish();
