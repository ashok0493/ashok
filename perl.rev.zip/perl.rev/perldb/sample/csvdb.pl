#!/usr/bin/perl
use strict;
use DBI;
sub file{
	open(my $data,"<$_[0]");
	my $line=<$data>;
	my @l=split(",",$line);
	my @lines=<$data>;
	my $db=DBI->connect("DBI:mysql:database=csv","root","ashok");
	my $sth=$db->prepare("drop table if exists ipl");
	$sth->execute();
	my $sth=$db->prepare("create table ipl($l[0] int(11) not null,$l[1] varchar(255),$l[2] varchar(255) not null,$l[3] int(11) not null)");
	$sth->execute();
	my $sth=$db->prepare("insert into ipl values(?,?,?,?)");
	foreach my $k (@lines){
		my @t=split(",",$k);
		$sth->execute($t[0],$t[1],$t[2],$t[3]);
		$sth->finish();
	}
	my $sth=$db->do("update ipl set NAME='pj' where ID=4");
	my $sth=$db->prepare("select * from ipl");
	$sth->execute();
	while (my @r=$sth->fetchrow_array()){
		print("$r[1]\n");
	}
	my $sth=$db->prepare("select * from ipl");
	$sth->execute();
	while (my $ref=$sth->fetchrow_hashref()){
		print("$ref->{'ID'},$ref->{'NAME'}\n")
	}
}
file("file.csv");

