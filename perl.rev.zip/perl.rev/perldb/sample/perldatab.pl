#!/usr/bin/perl
use strict;
use DBI;
my $db=DBI->connect("DBI:mysql:database=csv","root","ashok");
my $ktm=$db->prepare("drop table if exists team");
$ktm->execute();
$db->commit();
my $sth=$db->prepare("create table team(rank int(11) not null,teams varchar(255) not null,points int(11) not null)");
$sth->execute();
my $sd=$db->prepare("insert into team values(1,'india',126),(2,'australia',124),(3,'south africa',123),(4,'england',121)");
$sd->execute();
my $mak=$db->prepare("update team set teams='newzealand' where rank=4");
$mak->execute();
my $m=$db->prepare("select * from team");
$m->execute();
while (my @row=$m->fetchrow_array()){
	print("@row\n")
}
$m->finish();

