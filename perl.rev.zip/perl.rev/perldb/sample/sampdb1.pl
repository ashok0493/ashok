#!/usr/bin/perl
use DBI;
use strict;
my $db=DBI->connect("DBI:mysql:database=csv;host=localhost","root","ashok");
$db->do("insert into csvfile values(6,'ajay','embedded',40000)");
my $st=$db->prepare("select * from csvfile");
$st->execute();
while (my @row =$st->fetchrow_array()){
	my ($ID,$NAME,$SKILLS,$SALARY)=@row;
	print"ID=$ID,NAME=$NAME,SKILLS=$SKILLS,SALARY=$SALARY\n";
}
$st->finish();
