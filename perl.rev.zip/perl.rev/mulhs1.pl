#!/usr/bin/perl
sub val{
	my $h1=$_[0];
	my $h2=$_[1];
	#my($h1,$h2)=@_;
	foreach $k (keys %{$_[1]}){
		print"$k\n";
	}
}
%h1=('a'=>1,'b'=>2);
%h2=('c'=>3,'d'=>4);
val(\%h1,\%h2);
