#!/usr/bin/perl
$str='hello welcome to perl regular expressions and this pdf is forwed to this mail ids is ashokkumarmalipeddi@gmail.com and siva330@gmail.com';
@a=split(' ',$str);
@m=();

#print"@a\n";
foreach $_ (@a){
	if ($_=~/\w+\@\w+\.\w+/){
		push(@m,$&);
	}
}
print"@m";
		
