#!/usr/bin/perl
package srt;
use strict;
use warnings;
use Data::Dumper;
sub new{
	my $class=shift;
	my $self={hash=>{}};
	bless $self,$class;
	return $self;
}
sub csvred{
	my $self=shift;
	open(my $data,"<$_[0]");
	my $line=<$data>;
	my @sp=split(',',$line);
	my @lines=<$data>;
	foreach my $a (@lines){
		my @m=split(',',$a);
		#my $hash;
		$self->{hash}->{$m[0]}={};
		$self->{hash}->{$m[0]}->{$sp[1]}=$m[1];
		$self->{hash}->{$m[0]}->{$sp[2]}=$m[2];
		$self->{hash}->{$m[0]}->{$sp[3]}=$m[3];
=pod		
		$self->{$m[0]}={};
		$self->{$m[0]}->{$sp[1]}=$m[1];
		$self->{$m[0]}->{$sp[2]}=$m[2];
		$self->{$m[0]}->{$sp[3]}=$m[3];
=cut
		
	}
}
sub empdata{
	my $self=shift;
	if (exists($self->{hash}->{$_[0]})){
		print("emp_id :",$_[0],"\n");
		foreach my $s (keys(%{$self->{hash}->{$_[0]}})){
			print($s," : ",$self->{hash}->{$_[0]}->{$s},"\n");
		}
	}	
	else{
			print("$_[0] not found\n");
			print("required id's are sr01 to sr04");
	}
}

1;
#my $obj=new srt();
#$obj->csvred($ARGV[0]);
#$obj->empdata($ARGV[1]);
#print Dumper ($obj);
