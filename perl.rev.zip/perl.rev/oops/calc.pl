#!/usr/bin/perl
use calc;
my $obj=new calc();
$self->{'exp'}=10;
print %{$obj};
my $sum=$obj->add(20,30,40);
print"$sum\n";
