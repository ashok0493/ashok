#!/usr/bin/perl
package mi;
sub new{
	my $class=shift;
	my $self={firstname=>shift,lastname=>shift,surname=>shift};
	bless $self,$class;
	return $self;
}
sub setfirstname{
	my ($self,$firstname)=@_;
	$self->{firstname}=$firstname if defined($firstname);
	return $self->{firstname}	;
}
sub getfirstname{
	my($self)=@_;
	return $self->{firstname};
}
1;
$obj=new mi ('a','b','c');
$n=$obj->getfirstname();
$obj->setfirstname('k');
$n=$obj->getfirstname();
print($n);



