#!/usr/bin/perl
package bell;
sub new{
	my $class=shift;
	$self={"firstname"=>shift,"lastname"=>shift,"surname"=>shift};
	bless $self,$class;
	return $self;
}
sub getname{
	return $self->{"firstname"}
}
$obj=new bell("ashok","kumar","malipeddi");
print($obj->getname)
	
