#!/usr/bin/perl
use filex;
$obj=new rht();
$m=$obj->add('arun',24,05);
print %{$m};
