#!/usr/bin/perl
sub file{
	$s=shift;
	$a=shift;
	$h=shift;
	$h1=[shift,shift,shift];
	#print($s,@{$a},%{$h});
	print(@{$h1});
}
$a="ash";
@a=(1,2,3);
%h=('a'=>3,'b'=>5);
file($a,\@a,\%h);





=head
@ar=(1,2,3,4,5);
#$a=shift @ar;
foreach $a (shift @ar){
	print"$a\n";
}
