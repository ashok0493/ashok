#!/usr/bin/perl
use strict;
use warnings;
use csvfile;
#my $obj=new srt();
#$obj->csvred($ARGV[0]);
#$obj->empdata($ARGV[1]);
use Getopt::Long;
my $obj=new srt();
my $csvfile;
my $empdata;
my $help;
GetOptions("csvfile=s"=>\$csvfile,"empdata=s"=>\$empdata,"h|help"=>\$help)or die("error in command line argument\n");
if($help){
	&usage();
	}
if(not defined($csvfile)){
	print("-E enter csv file");
	exit;
	}
if (not defined($empdata)){
	print("-E enter emp_id");
	exit;
	}
if (-e $csvfile){
	$obj->csvred($csvfile);
	}
else{
	print("csv file doesn't exists");
	exit;
}
$obj->empdata($empdata);
sub usage{
	print"$0\n";
	print"script options\n";
	print"csvfile: provide input csv file.\n";
	print"    h(or)help:print halp Documentation.\n\n";
	print"Ex: $0 -c csvfile -e sr01\n";
	exit:
}
