#!/usr/bin/perl
package rht;
sub new{
	$class=shift;
	$self={};
	bless $self,$class;
	return $self;
}
sub add{
	$self=shift;
	$self={'name'=>shift,'age'=>shift,'id'=>shift};
#	return $self;
	}
$obj=new rht();
$m=$obj->add('ajay','22','01');
print %{$m};
1;
