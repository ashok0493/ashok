#!/usr/bin/perl
sub hsh{
	%h=%{@_[0]};
	while (($v,$k)=each (%h)){
		print($v,$k);
	}
	return
}
hsh({'b'=>35,'d'=>40,'e'=>45})
