#!/usr/bin/perl
use strict;
use JSON;
my $name="test";
my $type="a";
my $data="1.2.3";
my $tt1=84600;
my %rec_hash=('name'=>$name,'type'=>$type,'data'=>$data,'tt1'=$tt1);
print(%rec_hash);
