#!/usr/bin/perl
$s="helloworld";
print($s[3]);
