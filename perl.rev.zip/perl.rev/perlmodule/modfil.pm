#!/usr/bin/perl
use strict;
use warnings;
use Data::Dumper;
sub nam{
	open("l","<$_[0]");
	my @p=<l>;
	#print"@p\n";
	my %h=();
	foreach my $k (@p){
		my	@h=split(',',$k);
		$h{$h[0]}=[$h[1],$h[2],$h[3]];
		#print"$h{$h[0]}\n";
	}return (%h);
}
print Dumper (nam("file.csv"));

