#!/usr/bin/perl
use strict;
use warnings;
#use lib "/home/ashok-pc/Desktop/";
use prmod;
print"@INC\n";
print(Mak::add(1,2,3,5,6,7,8));
