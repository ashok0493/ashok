#!usr/bin/perl
require samp;
Foo::bar("a");
Foo::blat("b");
