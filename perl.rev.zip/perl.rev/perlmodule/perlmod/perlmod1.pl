#!/usr/bin/perl
use strict;
use warnings;
use lib "/home/ashok-pc/Desktop";
use prlmod;
print"@INC\n";
Test::add(5,10,15)
