package Test;

use vars qw(@ISA @EXPORT);
use Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(_add);

sub _add {
	my $sum = 0;
	foreach my $v (@_) {
		$sum = $sum + $v;			
	}	##end foreach
	return $sum;
}	##end sub


1; ##This is used to evaluate the module load to True;
