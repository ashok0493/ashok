#!/usr/bin/perl
use strict;
use warnings;

use lib "/home/srm/perl_modules";

use Test;

print "@INC\n";

my $sum = _add(10,11,24,23);
print "Test::$sum\n";

