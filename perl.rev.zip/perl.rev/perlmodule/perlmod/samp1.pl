#!/usr/bin/perl
use samp;
Foo::bar("a");
Foo::blat("b");
