#!/usr/bin/perl
package Mak;
use strict;
use warnings;
use vars qw(@ISA @EXPORT);
use Exporter;
@ISA=qw(Exporter);
@EXPORT=qw(_add);
sub add{
	my $sum=0;
	foreach my $k (@_){
		$sum=$sum+$k;
	}
	return $sum;	 
}
#print(add(1,2,3,4,5,6,7,8));
1;
