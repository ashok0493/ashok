#!/usr/bin/perl
open(data,">file2.txt");
print data"hello world this is perl tutorial\nthis is file handling topic\nthe above examples are shown in below";
open(data,"<file2.txt");
$line=<data>;
#print"$line\n";
while (<data>){
	print"$_\n";
}
@arr=(1,2,3,4,54);
while (@arr){
	print"$arr\n";
}
