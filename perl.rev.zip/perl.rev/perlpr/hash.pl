#!/usr/bin/perl
%d=('johnpaul',45,'lisa',30,'kumar',40);
#print $d{'johnpaul'};
#$d{'name'}='ashok';
#print %d;
%k=('paulwalkr'=>'f&f','leonard'=>'titanic');
#print $k{'paulwalkr'};
@l=@k{'paulwalkr','leonard'};
#print @l;
@n=keys %k;
#print @n;
@v=values %k;
#print @v;
### getting hash size###
@r=keys %k;
$o=@r;
#print $o;
$k{'ali'}=55;
@r=keys %k;
$b=@r;
#print $b;
delete $k{'ali'};
print %k;
