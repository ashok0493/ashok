#$a=`perl refernce.pl`;
#0print $a;
system('ifconfig')
