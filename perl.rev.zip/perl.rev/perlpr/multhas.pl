#!/usr/bin/perl
%h=("apple"=>{"ball"=>"red"},"orange"=>{"weigth"=>"1kg"});
@a=();
@b=();
while (($k,$j)=each (%h)){
	push(@a,$k);
	if (ref($j) eq "HASH"){
		while (($p,$q)=each %{$j}){
			push(@a,$p);
			push(@b,$q);
		}
	}
}
print(@a,"\n");
print(@b,"\n");
