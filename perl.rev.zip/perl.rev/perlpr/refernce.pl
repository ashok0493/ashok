#!/usr/bin/perl
@ar=(1,2,3);
#print"$ar[1]\n";
$arr=\@ar;
#print $arr;
@j=@{$arr};
#print @j;
#print $arr->[1];
$aref=[1,2,3];
#print @{$aref};
#print $aref->[0];
$arref1=[1,2,3,[4,5,6]];
#print @{$arref1->[3]};
#print $arref1->[3][0];
@ar1=(1,2,3,[4,5,6]);
#print $ar1[3]->[1];
%h=('a'=>1,'b'=>2);
#print $h{'b'};
$h{'b'}=4;
#print %h;
$k=\%h;
#print %{$k};
%m=%{$k};
#print %m;
#foreach $y (keys(%{$k})){
#	print $k->{$y};
#}
#foreach $j (keys(%{$k})){
#	print $k->{$j};
#}
%hsh=('a'=>1,'b'=>2);
$hash=\%hsh;
#print $hash;
#print $hash->{'b'};
#while (($k,$r)=each (%{$hash})){
#	print $k,$r;
#}
$arref=[1,2,3,[4,5,6]];
#print @{$arref->[3]};
$ar1=[1,2,3,[4,5,6,[7,8,9]]];
#print $ar1->[3][3]->[0];
#print @{$ar1->[3]->[3]}[0];
#print @{$ar1->[3]->[3]}[0..1];
%z=('a'=>22,'b'=>23,'c'=>24);
$g=\%z;
#print $g;
#print $$g{'b'};
%gps=('amd'=>[1,2,3],'str'=>[4,5,6],'gmr'=>45);
#print @{$gps{'amd'}};
#print @{$gps{'amd'}}[1];
$arr2=[1,[3,4,5],{'a'=>3,'b'=>[5,6,7]}];
#print $arr2->[1]->[1];
print @{$arr2->[2]->{'b'}};
