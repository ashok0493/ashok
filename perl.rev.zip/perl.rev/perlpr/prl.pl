#!/usr/bin/perl
%h=('a',1,'b',2);
@a=();
@b=();
while (($v,$j)=each (%h)){
	push (@a,$v);
	push (@b,$j);
}
print @a,"\n";
print @b,"\n";
