#!/usr/bin/perl
use XML::LibXML;
$dom = XML::LibXML->load_xml(location =>'s1.xml');
foreach $titl ($dom->findnodes('//employee')){
print($titl->getAttribute('./id'));
}
 
