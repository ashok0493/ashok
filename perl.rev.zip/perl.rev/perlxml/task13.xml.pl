#!/usr/bin/perl
#xml file to mysql create a table;
package task13;
use DBI;
use strict;
use warnings;
use Data::Dumper;
use XML::LibXML;
	sub new{
		my $class=shift;
		my $self={_db=>DBI->connect("DBI:mysql:database=csv","root","ashok"),dom=>XML::LibXML->load_xml(location=>'s1.xml')};
		bless $self,$class;
		return $self;
		print($self);
		}
	sub build_hash{
		my $self=shift;
		$self->{'hash'}={};
		foreach my $data ($self->{'dom'}->findnodes('/employee_data/employee')){
			#print($data->nodeName(),"\n");
			my $id=$data->findvalue('@id');
			my $name=$data->findvalue('name');
			my $exper=$data->findvalue('experience');
			my $skills=$data->findvalue('skills');
			$self->{'hash'}->{$id}={};
			$self->{'hash'}->{$id}{'name'}=$name;
			$self->{'hash'}->{$id}{'experience'}=$exper;
			$self->{'hash'}->{$id}{'skills'}=$skills;

			}
			#print Dumper ($self->{'hash'});
		}
	sub mysql{
		my $self=shift;
		my $sth=$self->{_db}->do("drop table if exists plxml");
	  $sth=$self->{_db}->prepare("create table plxml(id varchar(50) primary key not null,name char(50) not null,experience char(50) not null, skills char(50) not null)");
		$sth->execute();
		foreach my $data ($self->{'dom'}->findnodes('/employee_data/employee')){
			#print($data->nodeName(),"\n");
			my $id=$data->findvalue('@id');
			my $name=$data->findvalue('name');
			my $exper=$data->findvalue('experience');
			my $skills=$data->findvalue('skills');
			$sth=$self->{_db}->prepare("insert into plxml values(?,?,?,?)");
			$sth->execute($id,$name,$exper,$skills);
			}#end loop
			$sth=$self->{_db}->prepare("select * from plxml");
			$sth->execute();
			while (my @row=$sth->fetchrow_array()){
				#print("@row\n");
				}
		}

1;

my $obj=new task13();
$obj->build_hash();
$obj->mysql();
