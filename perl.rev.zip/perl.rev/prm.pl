#!/usr/bin/perl;
$b=<STDIN>;
foreach $a (1..$b){
	if ($a>1){
		foreach $m (2..$a){
			if ($a%$m==0){
				last;
			}
		}
	
	else{
		print($a);
		}
	}
}	
