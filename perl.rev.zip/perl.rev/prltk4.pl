#!/usr/bin/perl
use strict;
use Tk;
my $window = MainWindow->new;
$window->title("A first Tk Demo");
$window->Label(-text => "This is a chunk of descriptive text")->pack;
$window->Button(-text => "Print a value", -command => \&hash )->pack;
#$window->Button(-text => "Double the value", -command => sub {$val*=2} )->pack;
$window->Button(-text => "This is a quit button ", -command => \&finito )->pack;
MainLoop;
sub hash {
	my %h=%{$_[0]}; 
	foreach my $k (keys(%h)){
		print($k);
	#return
	}
}
my $d={'a'=>10,'b'=>20,'c'=>30};
hash($d);
sub finito{
	print "going away ...\n";
	#print "final value is $val\n";
	exit;
}
=pod
BEGIN {
	$val = 2;
}

