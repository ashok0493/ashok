#!/usr/bin/perl
$v='hi this is ashok mail is ashok@gmail.com';
$v=~ m/\w+\@\w+\.\w+/;
print"$&\n";
