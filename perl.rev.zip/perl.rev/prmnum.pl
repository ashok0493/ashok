#!/usr/bin/perl
print "enter the number till which you want to generate prime num";
$n=<STDIN>;
chomp($n);
print"the prime numbers n/w 2 and $n are:\n";
for ($i=3;$i<=$n;$i++){
	$is_prime=1;
	for(
