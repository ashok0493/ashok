#!/usr/bin/perl
sub uni{
	%h={};
	return keys %{{map{$_=>1}@_}};
}
@ar=('perl','php','perl','asp');
print join("",@ar),"\n";
print join("",uni(@ar)),"\n";
