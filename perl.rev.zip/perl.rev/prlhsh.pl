#!/usr/bin/perl
@num=(1,2,3,4,5);
@k=map{$_+1}grep{$_<5}@num;
print(@k);
