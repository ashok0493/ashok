#!/usr/bin/perl
use List::Util qw(first);
@r=qw(apples oranges brains toes);
#print @r;
$search="toes";
$index=first{$r[$_] eq $search}0..$#r;
print "index of $search=$index\n";
#print $ar[$_];
