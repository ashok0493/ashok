use warnings;
use LWP;
use Data::Dumper;
use HTTP::Request;
use LWP::UserAgent;
my $ua=LWP::UserAgent->new;
my $request=HTTP::Request->new(OPTIONS=>'http://127.0.0.1:8000/restapi/projects');
my $response=$ua->request($request);
print(Dumper($response));

