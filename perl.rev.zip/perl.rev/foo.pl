#!/usr/bin/perl
package foo;
sub user{
	$class=shift;
	$self={name=>shift,number=>shift,loc=>shift};
	bless $self,$class;
	return $self;
}
sub new{
	$self=shift;
	return $self;
	}
$obj=user foo('venky',984324239,'kkd');
$k=$obj->new();
print %{$k};
1;
