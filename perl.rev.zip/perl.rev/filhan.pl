#!/usr/bin/perl
=head
open(data,">file93");
print data "hello 
this topic is about
perl file handling";
=cut
open(bigd,"<file93");
while(<bigd>){
	print("$_");
	$m=<bigd>;
}
