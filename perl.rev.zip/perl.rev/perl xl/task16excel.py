#!/usr/bin/python3
# xecel file data in build dictionary and create a table in mysql
import pymysql
db=pymysql.connect("localhost","root","srm","siva1")
cur=db.cursor()
from openpyxl import load_workbook
wb=load_workbook('empty_book.xlsx')
print(wb.get_sheet_names())
ws=wb.active
r=[]
a=1
a1=[]
for i in ws:
	data=[]
	for s in i:
		if a==1:
			r.append(s.value)
		else:
			data.append(s.value)
	a+=1
	if len(data)>1:
		a1.append(data)
d={}
for i in range(len(a1)):
	d[a1[i][0]]={r[1]:a1[i][1],r[2]:a1[i][2],r[3]:a1[i][3]}
cur.execute("drop table if exists excelsheet1")
cur.execute("create table excelsheet1 ({} varchar(50) primary key not null,{} varchar(50) not null,{} bigint(11) not null,{} char(50) not null)".format(r[0],r[1],r[2],r[3]))
for i in a1:
	cur.execute("insert into excelsheet1 values('{}','{}',{},'{}')".format(i[0],i[1],i[2],i[3]))
db.commit()	
