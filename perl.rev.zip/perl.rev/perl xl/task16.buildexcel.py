#!/usr/bin/python3
#mysql data to create excel file in python code
#create a excel file in python code
import pymysql
from openpyxl import Workbook     #from openpyxl.workbook import Workbook
db=pymysql.connect("localhost","root","srm","siva1")
cur=db.cursor()
cur.execute("describe excelsheet1")
header1=[]
for i in cur.fetchall():
	header1.append(i[0])
cur.execute("select * from excelsheet1")
data=[]
for i in cur.fetchall():
	data.append(list(i))
#header = [u'Name', u'Email', u'Mobile', u'Currentlocation',]
#new_data = [[u'name1', u'email1@yahoo.com',u'9929283421', u'pavara'], 
 #           [u'name2', u'email2@xyz.com', u'9994191988', u'pithapuram']]
wb = Workbook()
dest_filename = 'empty_book.xlsx'
ws1 = wb.active
ws1.title = "range names"
ws1.append(header1)
for row in data:
	ws1.append(row)
wb.save(filename = dest_filename)
