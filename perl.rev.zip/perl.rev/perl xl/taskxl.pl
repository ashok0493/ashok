use Excel::Writer::XLSX;
my $workbook=Excel::Writer::XLSX->new('newsheet.xlsx');
$worksheet=$workbook->add_worksheet();

my $data = [
        [ "ID","NAME","SKILLS","SAL" ],
        [ 'srm01','balu','java','20000'],
        [ 'srm02','anand','corejava',25000],
        [ 'srm03','ramu','scripting',27000],
    ];
#print($data);
$worksheet->write_col('A1',$data);
#my $format=$workbook->add_format();
#$format->set_bold();
#$format->set_color('red');
#my @ed=(['maggie','milly','molly','may'],[13,14,15,16],['shell','star','crab','stone']);
#$worksheet->write_col('A1',\@ed,$format);

$workbook->close();
#$col=$row=0;
#$worksheet->write(1,2,'hiexcel')
#$worksheet->write('A5',12);
