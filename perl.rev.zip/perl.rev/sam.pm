#!/usr/bin/perl
package sam;
sub fun{
	$sum=0;
	@ar=@_;
	foreach $s (@_){
		$sum=$sum+$s;
	}
	return $sum;
}
#@ar=(1,2,3,4,5)
1;
