#!/usr/bin/perl
use DBI;
my $db=DBI->connect("DBI:mysql:database=csv","root","srm");
=head
my $kt=$db->prepare("select * from siva");
$kt->execute();
while (my @row=$kt->fetchrow_array()){
	print "@row\n";
}
=cut
my $kt=$db->do("select * from siva");
$kt->execute();
while (my @row=$kt->fetchrow_array()){
	print "@row\n";
}
$kt->finish();
#$db->commit();
