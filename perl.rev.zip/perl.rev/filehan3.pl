#!/usr/bin/perl
open(jalsa,"+<file4.txt");
#print jalsa"This example actually truncates (empties) the file before opening it for writing, which may not be the desired effect. If you want to open a file for reading and writing";
$line=<jalsa>;
#print"$line";
#print(tell jalsa);
seek jalsa,140,0;
print jalsa"forest";
print(getc jalsa);

#open(jalsa,">>file4.txt");
#print jalsa"to the extension of above file of filehandling";
#$line=<jalsa>;
#print"$line\n"
#sysopen(jalsa,"file4.txt",O_APPEND);
#print jalsa"come on come on";
#@lines=<jalsa>;
#print"@lines\n";
#sysopen("file6.txt",O_CREAT)
#close(jalsa)
