#!/usr/bin/perl
$a=10;
while ($a<20){
	if ($a==16){
		$a=$a+1;
		next
		#$a=$a+1;
	}
	print"$a\n";
	$a=$a+1;
}



	
