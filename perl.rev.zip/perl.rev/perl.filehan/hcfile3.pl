#!/usr/bin/perl
=head
$bar="this is foo and again foo";
if ($bar=~/foo/){
	print "first time is matching";
}else{
	print "first time is not matched";
}
=cut
$str="the food is i the salad bar";
#$str=~/foo/;
#print "before: $`\n";
#print "matched: $&\n";
#print "after: $'\n";
#$str=~s/the/this/;
#print $str;
#$str=~tr/the/this/;
#print $str;
$time="12/05/30";
$time=~s/(\d+)\/(\d+)\/(\d+)\//$3\/$2\/$1\//;
$time=~s/(\d+)\/(\d+)\/(\d+)\//$3\/$2\/$1\//;
print $time;

