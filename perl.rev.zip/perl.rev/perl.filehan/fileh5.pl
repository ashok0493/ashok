#!/usr/bin/perl
sysopen(data,"file20.txt",O_WRONLY);
print data"now u see me the magical part of magic cards";
sysopen(data,"file20.txt",O_RDONLY);
$line=<data>;
print"$line";

