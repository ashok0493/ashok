#!/usr/bin/perl
open(msd,"+>file24.txt");
print msd"hello world welcome to new";
