#!/usr/bin/perl
if (open(data,$file)){
	...
}else{
	die "error: couldn't open the file";
}
