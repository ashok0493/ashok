#!/usr/bin/perl
$mak='hei the current working company dtails of id is ashok3@gmail.com and srinu26@gmail.com and siva33@gmail.com';
@amd=split(' ',$mak);
#print"$amd[2]"
#@nda=();
foreach $_ (@amd){
	$_=~/\w+\@\w+\.\w+/;
	#print"$&\n"
	push(@nda,"$&")
}
print"@nda\n"
