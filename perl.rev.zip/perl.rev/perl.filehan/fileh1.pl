#!/usr/bin/perl
open(sng,">file1.txt");
print sng"hello world this is perl\n";
open(sng,"<file1.txt");
$line=<sng>;
print"$line\n";
open(sng,">>file1.txt");
print sng"sng is youth icon of power\nsng gives a milk daily 10litres\nsrinu is a old boy of glp\nsrinu is a busiest business man";
open(sng,"<file1.txt");
@lines=<sng>;
print"@lines";
