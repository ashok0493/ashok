#!/usr/bin/perl
open(boostr,"+<file4.txt");
print boostr"project 24\n";
open(boostr,"<file4.txt");
$line=<boostr>;
print"$line";

