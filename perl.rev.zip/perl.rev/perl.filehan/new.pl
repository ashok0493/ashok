#!/usr/bin/perl
@a=`ls`;
foreach $s (@a){
	print `cat $s`;
}
