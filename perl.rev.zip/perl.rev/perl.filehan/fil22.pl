#!/usr/bin/perl
open(details,"<file.txt");
@line=<details>;
$v=@line;
#print(tell details);
print(seek details,30,0),"\n";
@l=<details>;
print"@l";
print(tell details,"\n");
