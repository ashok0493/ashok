#!/usr/bin/perl
open(data,"<file") or  die "couldn't open file";
while (<data>){
	print "$_";
}
