#!/usr/bin/perl
#open(ash,">file1.txt");
#print ash "hello world"
open(mi,"<file1.txt");
$l=<mi>;
print"$l"
