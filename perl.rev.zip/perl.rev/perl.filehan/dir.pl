#!/usr/bin/perl
#opendir(DIR,'.');
#@f=readdir(DIR);
#print @f;
#closedir(DIR);
$dir="/home/ashok/Desktop/.py";
@file=glob($dir);
print @file;
