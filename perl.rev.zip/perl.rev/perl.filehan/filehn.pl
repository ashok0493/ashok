#!/usr/bin/perl
#open(sivaji,">file4");
#print sivaji"hello this is ashok";
open(sivaji,"<file4");
@line=<sivaji>;
print"@line"
