#!/usr/bin/perl
opendir (DIR,'.') or die "couldn't open directory";
@file=readdir DIR;
print @file;

#while ($file=readdir DIR){
#	print $file;
#}
closedir DIR;
