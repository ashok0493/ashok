#!/usr/bin/perl
open(srt,"+<file.txt");
print srt "here data is the file handle which will be used\nto read the file\nhere is the example which will open a file and will print its content over the screen";
open(srt,"<file.txt");
while (<srt>){
	print"$_";
}
