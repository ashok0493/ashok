#!/usr/bin/perl
open(data,"<file12.txt");
@d=<data>;
#print @d;
#open(dat,">file12.txt");
#print dat"hello welcome to loituc";
open(dat,"+>>file125.txt");
#print dat"super";
@k=<dat>;
print @k;
#print dat"zero size";
#@m=<dat
#print @m;
