#!/usr/bin/perl
package oopsprl;
sub new{
	$class=shift;
	$self=[shift,shift];
	bless $self,$class;
	return $self;
}
sub add{
	$self=shift;
	print(@_);
print(@{$self});
	return;
}
$obj=new oopsprl(11,22);
$obj->add(1,2,3);
