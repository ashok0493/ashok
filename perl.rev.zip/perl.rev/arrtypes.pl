#!usr/bin/perl
$var="rain-drops-on-roses-and-wiskers";
@an=split('-',$var);
@an=sort(@an);
print"@an\n";
@numbers=(1,3,(4,5,6));
print"@numbers";

