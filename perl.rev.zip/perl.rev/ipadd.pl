#!/usr/bin/perl
@a=`ifconfig`;
#print(@a);
$m=`ifconfig`;
#print($m);
#@k=@a;
#print(@k);
foreach $j (@a){
	if ($j=~m/(.*)\d+\.\d+\.\d+\.\d+/){ 
		print($&,"\n");
		#last
	}
	#last
}
