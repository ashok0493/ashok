$sum = 0;
 
$count = 0;
 
print "Enter number: ";
 
$num = <>;
 
chomp($num);
 
while ($num >= 0)
 
{
 
$count++;
 
$sum += $num;
 
print "Enter another number: ";
 
$num = <>;
 
chomp($num);
 
}
 
print "$count numbers were entered\n";
 
if ($count > 0)
 
{
 
print "The average is ",$sum/$count,"\n";
 
}
 
exit(0);
