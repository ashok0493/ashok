#!/usr/bin/perl
use Lwp::Simple;
my $url='http://www.google.com/';
my $content=get $url;
die "couldn't get $url" unless defined $content;
print $content;
