#!/usr/bin/perl
=head
@list=(1,"test",2,"sample",3,4);
@l=grep /\d+/,@list;
print(@l);
=cut
$dirname="/home/ashok/Desktop/";
opendir(DIR,$dirname)||die"error in opening dir $dirname\n";
while(($dirname=readdir(DIR))){
	print("$filename\n");
}
closedir(DIR);
