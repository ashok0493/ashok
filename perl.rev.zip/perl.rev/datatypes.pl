#!/usr/bin/perl
use Data::Dumper;
=head
$var=25;
$name="ashok";
$value=144.5;
print"$var\n$name\n$value\n";
print"$var";
print"$name";
print"$value";

@arr=(25,30,45,50,55,60,65,70);
@arr1=("ashok","anand","ramu");
print"@arr\n";
#print"helloworld"
print"@arr1[0..1]";


%has=('ashok',23,'kumar',22,'pawan',25);
$has{'rohit'}=27;
delete $has{'rohit'};
print Dumper (\%has);
=head
%has1=('kamal'=>24,'suresh'=>25,'ramesh'=>26);
@keys=keys (%has);
print"$has{'ashok'} $has1{'kamal'}\n";
print Dumper (\%has);
print"@keys";
@names=('ashok','kasi','ravi');
@c=@names;
$s=@names;
#print"@c\n $s"

#use multi line use single quotes
$str='hello
world
this is perl';
print"$str";

$a=10;
$var =<<'EOF';
hello this is perl datatypes oa scalar and value is $a 
EOF
print"$var\n"

print <<EOF;
hi this is ashok from 
EOF;
=cut
print __FILE__ ."\n";

