#!/usr/bin/perl
opendir(DIR,'.');
@f=readdir(DIR);
#closedir DIR;
foreach  @f{
	print "$_";
}
