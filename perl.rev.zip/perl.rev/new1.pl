#!/usr/bin/perl
$dir=/home//ashok/;
@files=glob($dir);
foreach (@files){
	print $_;
}
