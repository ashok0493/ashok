#!/usr/bin/perl
@a=(1,2,3,45,5,6,7);
foreach $s (@a){
 print($s);
}
print($a[45])
