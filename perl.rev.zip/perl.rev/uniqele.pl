#!/usr/bin/perl
use strict;
use Data::Dumper;
my $ab="prabath vamsi vamsi eswar sandhya vinayaka";
my @a=split /\s+/,$ab;
print(@a);
my %uni=map{$_}@a;
my @final=keys %uni;
print(@final,"\n");
print Dumper(\@final);
1;
