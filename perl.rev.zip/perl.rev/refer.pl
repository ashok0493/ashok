#!/usr/bin/perl
use Data::Dumper;
=head
#method 1
@arr1=(1,2,3,4);
print"@arr1\n";
$a=\@arr1;
print"$$a[1]\n";
#method 2
$arrref=[1,2,3,4];
print"$$arrref[1]\n";
print"$arrref->[1]\n";

#multi dimension
$arref=[1,2,3,[4,5,6]];
print"$$arref[3][1]\n";
print"$arref->[3][1]\n";
print"$arref->[3]->[0]\n";
print"@$arref[2]\n";
print"@{@$arref[3]}\n";
print"@{$arref->[3]}\n";

$a=10;
$v=\$a;
print ref($v),"\n";
$arr=[1,2,3,5,[6,7,8]];
print"@{@$arr[4]}\n";
print"@{$arr->[4]}\n";
print"$arr->[1]\n";
print"@$arr[0..2]\n";

$arr1=[1,2,3,[4,5,6,[7,8,9]]];
print"@{$arr1->[3]->[3]}\n";
print"@{$arr1->[3]->[3]}[0]\n";
print"@{$$arr1[3][3]}[0..2]\n";
print"@{$arr1->[3]}[1]\n";
print"$arr1->[3]->[1]\n";
print"@{$arr1->[3]}\n";

%has=('a'=>22,'b'=>23,'c'=>24);
$h=\%has;
print "$$h{'b'}\n";
#print %{$h};
$ha={'a'=>22,'b'=>12,'c'=>20};
print %{$ha{'c'}};
print "$$ha{'b'}\n";
print"$ha->{'a'}\n";

%has=('amd'=>[1,2,3,4],'str'=>4,'gmr'=>45);
$var=\%has;
print "@{$var->{'amd'}}[0..3]\n";
print "@{$$var{'amd'}}[0..3]\n";
print "@{$var->{'amd'}}\n";
print "$var->{'str'}";
print"@{$$var{'amd'}}[2]\n";

@arr2=(1,2,3,[4,5,[0,1,2,[4,6,10,30],6,12],3,6],7,8);
$arr2=\@arr2;
#print"$arr2->[2]\n";
print"@$arr2[4..5]\n";
print"@{$arr2->[3]->[2]->[3]}[2..3]\n";
print"@$arr2[4..5]\n";

%ha1=('a'=>[1,2,3,{'b'=>[1,2,3,4]},5,6],'c'=>[11,12,13,14]);
$ha1=\%ha1;
#print"@{$ha1->{'a'}->[3]->{'b'}}\n";
#print"$ha1->{'c'}[2]\n";
#print"@{$ha1->{'c'}}[1..2]\n";
$ha1->{'c'}=[1,2,4,5];
print"@{$ha1->{'c'}}\n";
print @{$ha1->{'c'}}
@ask=(1,2,3,4);
$m=\@ask;
print"@$m\n";
$ask1=[1,2,[3,4,5],{'a'=>1,'b'=>[6,7,8]},9];
print"@{$ask1->[2]}\n";
print"$ask1->[3]{'a'}\n"; 
print @{$ask1->[3]{'b'}},"\n";
print $ask1->[3]->{'b'}[0],"\n";
=cut
$m=[1,2,[3,4]];
if ($m=~/$m/){
	print"$&";
}
elsif ($m=~/D+/){
	print"$&";
}
else{
print 'sng';
}
$ask1=[1,2,[3,4,5],{'a'=>1,'b'=>[6,7,8]},9];
print  "$ask1->[3]->{'b'}->[0]\n";
print Dumper $ask1->[3];
