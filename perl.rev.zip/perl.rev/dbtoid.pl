#!/usr/bin/perl
use DBI;
use strict;
my $dbh=DBI->connect("DBI:mysql:database=csv","root","srm");
my $sth=$dbh->prepare("select * from csvfile where id =$ARGV[0]");
$sth->execute();
my @ar=$sth->fetchrow_array();
print("id :",$ar[0]);
