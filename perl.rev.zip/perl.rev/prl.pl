#!/usr/bin/perl
#print("name","age");
$str="hello"."world";
print($str);
$num=5+4;
print($num);
$m="\Uhello welcome to python";
print($m)
